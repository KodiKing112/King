# -*- coding: utf-8 -*-
import os,sys,re,threading,urllib,time
from os import listdir
from os.path import isfile, join
def get_sec(time_str):
    h, m, s = time_str.split(':')
    return str(int(h) * 3600 + int(m) * 60 + int(s))
def get_param(tv_movie,name1,original_title,season,episode,season_n,episode_n,show_original_year,name):
        
        if (name1=='lavin' or name1=='odb') and tv_movie=='movie':
            original_title='Bohemian Rhapsody'
        elif name1=='oneh' and tv_movie=='movie':
            
            original_title='aladdin'
        elif name1=='onet' and tv_movie=='movie':
            original_title='3 Days to Kill'
        elif name1=='dnv' and tv_movie=='movie':
            original_title='Instant Family'
        elif name1=='hdm' and tv_movie=='movie':
            original_title='Avengers: Endgame'
            show_original_year='2019'
        elif name1=='seehd'  and tv_movie=='movie':
            
           
            original_title='bumblebee'
        elif name1=='rftv' and tv_movie=='movie':
            original_title='captain marvel'
            show_original_year='2019'
        elif name1=='hndm' and tv_movie=='movie':
            original_title='dumbo'
            show_original_year='2019'
        elif (name1=='wsse' or name1=='scen' or name1=='seehd' or name1=='2ddl') and tv_movie=='tv':
            
           
            season='6'
            episode='5'
            season_n='06'
            episode_n='05'
        elif (name1=='seehd' or name1=='m4u' or name1=='clv') and tv_movie=='tv':
            
           
            season='5'
            episode='15'
            season_n='05'
            episode_n='15'
        
        elif name1=='sol' and tv_movie=='movie':
            original_title='Moonlight'
        elif (name1=='pkl' or name1=='allu' or name1=='mesh' ) and tv_movie=='tv':
            
           
            season='4'
            episode='20'
            season_n='04'
            episode_n='20'
        elif name1=='mosh' and tv_movie=='movie':
            original_title='Anna'
            show_original_year='2019'
            name='אנה'
        elif (name1=='mds' or name1=='mosh'):
            original_title='joker'
            show_original_year='2019'
        
        elif (name1=='rapid' or name1=='vidc' or name1=='ap2s' or name1=='prf') and tv_movie=='tv':
            
           
            season='6'
            episode='3'
            season_n='06'
            episode_n='03'
        elif (name1=='soup' or name1=='wss_n') and tv_movie=='tv':
            
           
            season='6'
            episode='1'
            season_n='06'
            episode_n='01'
        elif (name1=='p4m' or name1=='treplus') and tv_movie=='tv':
            season='4'
            episode='18'
            season_n='04'
            episode_n='18'
            
        elif name1=='tmv' and tv_movie=='tv':
            season='5'
            episode='20'
            season_n='05'
            episode_n='20'
        elif name1=='moviesak' and tv_movie=='tv':
            
           
            season='5'
            episode='1'
            season_n='05'
            episode_n='01'
        elif (name1=='rts' or name1=='tvs' or name1=='rftv' ) and tv_movie=='tv':
            if name1=='rftv':
                season='1'
                episode='1'
                season_n='01'
                episode_n='01'
                original_title='arrow'
            else:
                original_title='The Walking Dead'
           
                season='10'
                episode='1'
                season_n='10'
                episode_n='01'
        elif name1=='sez':
            original_title='the good doctor'
            season='1'
            episode='1'
            season_n='01'
            episode_n='01'
        elif (name1=='tvl'  or name1=='mkvc' or name1=='ct' or name1=='ftp' or name1=='zcm' or name1=='shd') and tv_movie=='tv':
            
           
            season='5'
            episode='1'
            season_n='05'
            episode_n='01'
        elif (name1=='cool' or name1=='magnet_api') and tv_movie=='tv':
            season='1'
            episode='1'
            season_n='01'
            episode_n='01'
        elif name1=='dragon' and tv_movie=='tv':
            name='קריפטון'
            season='1'
            episode='1'
            season_n='01'
            episode_n='01'
            show_original_year='2018'
        elif name1=='extra' or name1=='genv' or name1=='sc' :
            original_title='Tomb Raider'
            show_original_year='2018'
        elif name1=='dizi' and tv_movie=='tv':
            original_title='supergirl'
            season='1'
            episode='1'
            season_n='01'
            episode_n='01'
            show_original_year='2015'
        elif (name1=='hndm' or name1=='vex' or name1=='dizi' ) and tv_movie=='movie':
            original_title='venom'
            show_original_year='2018'
        elif name1=='cen' and tv_movie=='movie':
            original_title='deadpool 2'
            show_original_year='2018'
        elif name1=='opws' and tv_movie=='movie':
            original_title='tomb raider'
            show_original_year='2018'
        elif name1=='dwatch' and tv_movie=='movie':
            original_title='venom'
            show_original_year='2018'
        elif name1=='flix' and tv_movie=='movie':
            original_title='tomb raider'
        elif name1=='mf' and tv_movie=='movie':
            original_title='tomb raider'
            show_original_year='2018'
        elif name1=='orn' and tv_movie=='movie':
            name='12 לוחמים'
            show_original_year='2018'
        else:
            print 'Else'
            if tv_movie=='tv':
                original_title='the flash'
                show_original_year='2014'
                season='5'
                episode='1'
                season_n='05'
                episode_n='01'
                id='60735'
                name='הפלאש'
                
            else:
                original_title='rampage'
                show_original_year='2018'
                season='%20'
                episode='00'
                season_n='00'
                episode_n='00'
                id='427641'
                name='פרא'
        
        return original_title,season,episode,season_n,episode_n,show_original_year,name
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)
start=time.time()
print start
name_check=''
if len(sys.argv)>1:
   print sys.argv
   name_check=sys.argv[1]
if name_check=='tv':

    tv_movie='tv'
    name_check=''
elif name_check=='movie':
    tv_movie='movie'
    name_check=''
else:
    tv_movie='tv'

if tv_movie=='tv':
    original_title='the flash'
    show_original_year='2014'
    season='5'
    episode='1'
    season_n='05'
    episode_n='01'
    id='60735'
    name='הפלאש'
    
else:
    original_title='rampage'
    show_original_year='2018'
    season='%20'
    episode='00'
    season_n='00'
    episode_n='00'
    id='427641'
    name='פרא'

dir_path = os.path.dirname(os.path.realpath(__file__))
mypath=os.path.join(dir_path,'done')

rd_dir = os.path.join(dir_path, 'done','rd')
sys.path.append( rd_dir)
mag_dir = os.path.join(dir_path ,'done','magnet')
sys.path.append( mag_dir)


onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
onlyfiles =onlyfiles +[f for f in listdir(rd_dir) if isfile(join(rd_dir, f))]+[f for f in listdir(mag_dir) if isfile(join(mag_dir, f))]
sys.path.append(mypath) 
dir_path = os.path.dirname(os.path.realpath(__file__))
solvers_path=os.path.join(dir_path,'solvers')
sys.path.append(solvers_path) 
libDir = os.path.join(dir_path,'solvers','resolver')

sys.path.append( libDir)

f_result={}
all_sources=[]

original_title,season,episode,season_n,episode_n,show_original_year,name=get_param(tv_movie,name_check,original_title,season,episode,season_n,episode_n,show_original_year,name)

for items in onlyfiles:
   if items!='__init__.py' and items !='general.py' and '.pyc' not in items and '.pyo' not in items and 'resolveurl_temp.py' not in items and items !='resolveurl.py' and items !='Addon.py' and items !='cache.py' and items!='cloudflare.py':

       impmodule = __import__(items.replace('.py',''))
       
       if name_check!='' and name_check!='all':
         if items.replace('.py','')==name_check:
           if tv_movie=='movie' and 'movie' in impmodule.type:
             all_sources.append((items.replace('.py',''),impmodule))
           elif tv_movie=='tv' and 'tv' in impmodule.type:
             all_sources.append((items.replace('.py',''),impmodule))
       else:
         
         if tv_movie=='movie' and 'movie' in impmodule.type:
           all_sources.append((items.replace('.py',''),impmodule))
         elif tv_movie=='tv' and 'tv' in impmodule.type:
      
           all_sources.append((items.replace('.py',''),impmodule))
thread=[]
print len(all_sources)
string_dp=''
if name_check=='all':
    report=''
    counter=0
    for i in range(0,2):
        if i==0:
          tv_movie='tv'
        elif i==1:
          tv_movie='movie'
        else:
          break
      

        if tv_movie=='tv':
            original_title='the flash'
            show_original_year='2014'
            season='5'
            episode='1'
            season_n='05'
            episode_n='01'
            id='60735'
            name='הפלאש'
            
        else:
            original_title='tomb raider'
            show_original_year='2018'
            season='%20'
            episode='00'
            season_n='00'
            episode_n='00'
            id='427641'
            name='פרא'
        print tv_movie
        all_sources=[]
        for items in onlyfiles:
           if items!='__init__.py' and items !='general.py' and '.pyc' not in items and '.pyo' not in items and 'resolveurl_temp.py' not in items and items !='resolveurl.py' and items !='Addon.py' and items !='cache.py' and items!='cloudflare.py':
               f_in=os.path.join(mypath,items)
               file = open(f_in, 'r') 
               file_in=file.read() 
               impmodule = __import__(items.replace('.py',''))
               
               if name_check!='' and name_check!='all':
                 if items.replace('.py','')==name_check:
                   if tv_movie=='movie' and 'movie' in impmodule.type:
                     all_sources.append((items.replace('.py',''),impmodule))
                   elif tv_movie=='tv' and 'tv' in impmodule.type:
                     all_sources.append((items.replace('.py',''),impmodule))
               else:
                 
                 if tv_movie=='movie' and 'movie' in impmodule.type:
                   all_sources.append((items.replace('.py',''),impmodule))
                 elif tv_movie=='tv' and 'tv' in impmodule.type:
              
                   all_sources.append((items.replace('.py',''),impmodule))
        start_all=time.time()
        report=report+'\n-----------------------'+tv_movie+'------------------------\n\n'
        print '\n-----------------------'+tv_movie+'------------------------\n\n'
        for name1,items in all_sources:
            try:

                original_title,season,episode,season_n,episode_n,show_original_year,name=get_param(tv_movie,name1,original_title,season,episode,season_n,episode_n,show_original_year,name)
                report=report+name1+' : Start'+'\n\n'
                sys.stdout.write("\r {0},{1} ".format(name1,string_dp))
                start_time=time.time()
                thread=[]
                if (tv_movie=='movie' and 'movie' in items.type) or (tv_movie=='tv' and 'tv' in items.type):
                  if name1=='rts' and tv_movie=='tv':
                     original_title='The Walking Dead'
                  thread.append(Thread(items.get_links,tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id))
                  thread[0].start()
               
                  while thread[0].is_alive():
                    a=1
                #x=items.get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id)
                    
                    
                    
                    
                    
                    
                   
                count_rest=0
                count_1080=0
                count_720=0
                count_480=0
                all_servers=[]
                if 'subs' not in name1:
                  for data in items.global_var:
                            
                             name3,links,server,res=data
                             all_servers.append(server)
                             if '1080' in res:
                               count_1080+=1
                             elif '720' in res:
                               count_720+=1
                             elif '480' in res:
                               count_480+=1
                             else:
                               count_rest+=1
                else:
                   count_1080=len(items.global_var)
                string_dp="1080: %s 720: %s 480: %s Rest: %s"%(count_1080,count_720,count_480,count_rest)
                sys.stdout.write("\r {0},{1} ".format(name1,string_dp))
                elapsed_time = time.time() - start_time
                if count_1080==0 and count_720==0 and count_480==0 and count_rest==0:
                 
                 if  (tv_movie=='movie' and 'movie' in items.type) or (tv_movie=='tv' and 'tv' in items.type):
                  error='ERRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR'
                else:
                  error=''
                print name1 +' - '+error
                report=report+'['+name1+'] : \n'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))+'\n'+string_dp+'  - ' +error+'Servers={'+','.join(all_servers)+'}END'+'\n\n'
              
            
                sys.stdout.write("\r {0},{1} ".format(name1,string_dp))
                sys.stdout.flush()
                #counter+=1
                #if counter>3:
                #      break
            except (KeyboardInterrupt, SystemExit):
                   for name1,items in all_sources:
                     for threads in thread:
                       if threads.is_alive():
                         
                         threads._Thread__stop()
                       items.stop_all=1
                   print 'Break all'
                   break
    elapsed_all = time.time() - start_time
    report=report+'Final time : \n'+time.strftime("%H:%M:%S", time.gmtime(elapsed_all))+'\n\n'
    file = open('report.txt','w') 
 
    file.write(report) 
   
     
    file.close()  
else:
    for name1,items in all_sources:
        f_result[name1]= items.global_var
        if name_check!='':
           
           original_title,season,episode,season_n,episode_n,show_original_year,name=get_param(tv_movie,name_check,original_title,season,episode,season_n,episode_n,show_original_year,name)
            
           if name1==name_check:
             print name1
             thread.append(Thread(items.get_links,tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id))
             thread[len(thread)-1].setName(name1)
        else:
          
          original_title,season,episode,season_n,episode_n,show_original_year,name=get_param(tv_movie,name1,original_title,season,episode,season_n,episode_n,show_original_year,name)
          thread.append(Thread(items.get_links,tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id))
          thread[len(thread)-1].setName(name1)
    print len(thread)
    for td in thread:
          td.start()

    str1=''
    str2=''
    from clint.textui import colored

    still_alive=0
    x=0
    while 1:

        ir={}
        for threads in thread:
            try:
                alive_ones=[]
                still_alive=0
                for yy in range(0,len(thread)):
                        if thread[yy].is_alive():
                          alive_ones.append(thread[yy].getName())
                          ir[thread[yy].getName()]=colored.cyan(thread[yy].getName())
                          still_alive=1
                        else:
                          ir[thread[yy].getName()]=colored.yellow(thread[yy].getName())
                all_links_togther=[]
                count_rest=0
                count_1080=0
                count_720=0
                count_480=0
                f_result={}
                prog={}
                
                for name1,items in all_sources:
                  
                   f_result[name1]= items.global_var
                   try:
                    prog[name1]=items.progress
                   except:
                    prog[name1]=''
                   progress=prog[name1]
                   if name1!='subs':
                     
                     all_links_togther=all_links_togther+f_result[name1]
                   
                links_in=''
               
                all_servers=[]
                
                for data in all_links_togther:
                        
                         name1,links,server,res=data
                         
                         if '1080' in res:
                           count_1080+=1
                         elif '720' in res:
                           count_720+=1
                         elif '480' in res:
                           count_480+=1
                         else:
                           count_rest+=1
                         all_servers.append(server)
                         
                         
                         
                all_names=[]
                str1=' '
                
                for items in f_result:
                    all_names.append((items,len(f_result[items])))
                    
                    if threads.is_alive() and items==threads.getName():
                      str1=str1+ir[items]+' : '+str(len(f_result[items]))
                    else:
                    
                      str1=str1+ir[items]+' : '+str(len(f_result[items]))
                if len(alive_ones)<10:
                
                    txt=",".join(alive_ones)
                else:
                    txt=str(len(alive_ones))
                string_dp="1080: %s 720: %s 480: %s Rest: %s Src:%s   "%(count_1080,count_720,count_480,count_rest,txt)
                x+=1
                sys.stdout.write("\r {0} ".format(string_dp))
                sys.stdout.flush()
                time.sleep(0.2)
             
            except (KeyboardInterrupt, SystemExit):
               
               for name1,items in all_sources:
                 for threads in thread:
                   if threads.is_alive():
                     
                     threads._Thread__stop()
                   items.stop_all=1
               print 'Break all'
               break
  
        time.sleep(0.5)
        if still_alive==0:
               break
all_names=[]
all_mount=[]
report='-------------%s-------------------\n'%tv_movie
count_f=0
all_type_links=[]
num=0
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
for items in f_result:
    if len(f_result[items])>0:
       if items!='subs':
        all_links=[]
        all_servers=[]
        for item in f_result[items]:
            name1,links,server,res=item
            all_links.append(links)
            if '1fichier.com' not in links and 'magnet' not in items and 'filefactory' not in links and 'turbobit' not in links and 'nitroflare' not in links and 'rapidgator' not in links and 'Direct' not in server and 'uploaded.net' not in links:
                all_type_links.append(str(num)+' . '+links.encode('ascii','ignore') +' - '+items.encode('ascii','ignore'))
            num+=1
            if '{P' not in server and server not in all_servers:
                all_servers.append(server)
        try:
            progress=get_sec(prog[items].replace('Done',''))
        except:
            progress='999'
        report=report+'Start:['+items+'] : \nlinks='+str(len(all_links))+', Servers={'+','.join(all_servers)+'}<%s>END'%progress+'\n\n'
        all_names.append((items,len(all_links),','.join(all_servers)))
        
        
    else:
       report=report+'Start:['+items+'] : \n{ERRRRRRRRRRRRRRRRRRRRRORRRR} END\n\n'
       count_f=count_f+1
report=report+'---------------------\nFault: %s \n'%str(count_f)
report=report+'-------------END %s-------------------'%tv_movie

print time.time()-start

    
if name_check=='':
    file = open('report_%s.txt'%tv_movie,'w') 

    file.write(report) 

 
    file.close()
    
    file = open('all_links_%s.txt'%tv_movie,'w') 

    file.write(('\n'.join(all_type_links)).encode('ascii','ignore'))

 
    file.close() 
    
    print 'Done'    
else:
    print f_result
   
    try:
        
        print progress+' Sec'
        #print 'progress:'+progress
    except Exception as e:
     
     print 'NO PROGRESS '+str(e)