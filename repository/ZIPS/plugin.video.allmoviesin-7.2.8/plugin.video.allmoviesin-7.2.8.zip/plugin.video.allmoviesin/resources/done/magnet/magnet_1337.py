# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
try:
 import xbmcgui
 local=False
except:
 local=True
 
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
try:
    from general import Addon
except:
  import Addon
type=['movie','tv','torrent']

import urllib2,urllib,logging,base64,json

color=all_colors[110]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    if tv_movie=='movie':
      search_url=clean_name(original_title,1).replace(' ','-')+'-'+show_original_year
      s_type='Movies'
    else:
      search_url=clean_name(original_title,1).replace(' ','-')+'-s'+season_n+'e'+episode_n
      s_type='TV'
  
    rd_sources=Addon.getSetting("rdsource")
    allow_debrid = rd_sources == "true" 
    
    all_links=[]
    
    for page in range(1,7):
        if stop_all==1:
            break
            
        x,cook=cloudflare_request('http://www.1377x.to/',headers=base_header)
       
        x=requests.get('http://www.1377x.to/category-search/%s/%s/%s/'%(search_url+'-2160',s_type,str(page)),headers=cook[1],cookies=cook[0]).content
        
        
        regex_pre='<tr>(.+?)</tr>'
        m_pre=re.compile(regex_pre,re.DOTALL).findall(x)
        if len(m_pre)==0:
           break
        for items in m_pre:
            regex='<i class="flaticon.+?">.+?a href="(.+?)">(.+?)<.+?seeds">(.+?)<.+?leeches">(.+?)<.+?size.+?">(.+?)<'
            macth_pre=re.compile(regex,re.DOTALL).findall(items)
            if stop_all==1:
                 break
        
                
                
            for link,title,seed,peer,size, in macth_pre:
            
                         if stop_all==1:
                            break
                         if '4k' in title:
                              res='2160'
                         elif '2160' in title:
                              res='2160'
                         elif '1080' in title:
                              res='1080'
                         elif '720' in title:
                              res='720'
                         elif '480' in title:
                              res='480'
                         elif '360' in title:
                              res='360'
                         else:
                              res='HD'
                        
                         o_link=link
                       
                         try:
                             o_size=size
                             size=float(o_size.replace('GB','').replace('MB','').replace(",",'').strip())
                             if 'MB' in o_size:
                               size=size/1000
                         except Exception as e:
                            
                            size=0
                         max_size=int(Addon.getSetting("size_limit"))
                        
                         if size<max_size:
                           if allow_debrid:
                                x=requests.get('http://www.1377x.to'+o_link,headers=cook[1],cookies=cook[0]).content
                                regex='"magnet(.+?)"'
                                mm=re.compile(regex).findall(x)
                                lk='magnet'+mm[0]
                           else:
                                lk='http://www.1377x.to'+o_link
                           all_links.append((title,lk,'- 1337 - '+str(size)+' GB'+' {P-%s/S-%s}'%(peer,seed),res))
                       
                           global_var=all_links
    for page in range(1,7):
        if stop_all==1:
            break
        x=requests.get('http://www.1377x.to/category-search/%s/%s/%s/'%(search_url,s_type,str(page)),headers=cook[1],cookies=cook[0]).content
       
        regex_pre='<tr>(.+?)</tr>'
        m_pre=re.compile(regex_pre,re.DOTALL).findall(x)
        if len(m_pre)==0:
           break
        for items in m_pre:
            regex='<i class="flaticon.+?">.+?a href="(.+?)">(.+?)<.+?seeds">(.+?)<.+?leeches">(.+?)<.+?size.+?">(.+?)<'
            macth_pre=re.compile(regex,re.DOTALL).findall(items)
            if stop_all==1:
                break
        
                
                
            for link,title,seed,peer,size, in macth_pre:
                         if stop_all==1:
                            break
                         if '4k' in title:
                              res='2160'
                         elif '2160' in title:
                              res='2160'
                         elif '1080' in title:
                              res='1080'
                         elif '720' in title:
                              res='720'
                         elif '480' in title:
                              res='480'
                         elif '360' in title:
                              res='360'
                         else:
                              res='HD'
                        
                         o_link=link
                       
                         try:
                             o_size=size
                             size=float(o_size.replace('GB','').replace('MB','').replace(",",'').strip())
                             if 'MB' in o_size:
                               size=size/1000
                         except Exception as e:
                            
                            size=0
                         max_size=int(Addon.getSetting("size_limit"))
                        
                         if size<max_size:
                           if allow_debrid:
                                x=requests.get('http://www.1377x.to'+o_link,headers=cook[1],cookies=cook[0]).content
                                regex='"magnet(.+?)"'
                                mm=re.compile(regex).findall(x)
                                lk='magnet'+mm[0]
                           else:
                                lk='http://www.1377x.to'+o_link
                           all_links.append((title,lk,'- 1337 - '+str(size)+' GB'+' {P-%s/S-%s}'%(peer,seed),res))
                       
                           global_var=all_links
    return global_var
        
    