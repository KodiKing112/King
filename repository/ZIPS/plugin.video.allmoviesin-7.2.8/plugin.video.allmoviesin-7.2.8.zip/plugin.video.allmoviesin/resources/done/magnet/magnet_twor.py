# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
try:
 import xbmcgui
 local=False
except:
 local=True
 
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
try:
    from general import Addon
except:
  import Addon
type=['movie','tv','torrent']

import urllib2,urllib,logging,base64,json

color=all_colors[90]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    if tv_movie=='movie':
      search_url=clean_name(original_title,1).replace(' ','%20')+'%20'+show_original_year
      s_type='Movies'
      type='4'
    else:
      search_url=clean_name(original_title,1).replace(' ','%20')+'%20s'+season_n+'e'+episode_n
      s_type='TV'
      type='8'
  
    rd_sources=Addon.getSetting("rdsource")
    allow_debrid = rd_sources == "true" 
    
    all_links=[]
    
 
    for page in range(0,1):
        if stop_all==1:
            break
        x=requests.get('https://www.torrentdownloads.me/search/?page=%s&search=%s&s_cat=%s&srt=seeds&pp=50&order=desc'%(str(page),search_url,type),headers=base_header).content
      
   
        
        regex_pre='<div class="grey_bar3(.+?)</div>'
        
        m_pre=re.compile(regex_pre,re.DOTALL).findall(x)
        if len(m_pre)==0:
             
                break
        for items in m_pre:
            regex_pre='a href="(.+?)".+?info.+?>(.+?)<.+?<span>(.+?)<.+?<span>(.+?)<.+?<span>(.+?)<'
            m_p=re.compile(regex_pre,re.DOTALL).findall(items)
            if stop_all==1:
                break
            
            
                    
            
            for link,title,seed,peer,size in m_p:
                             if 'search' in link:
                                continue
                             if stop_all==1:
                                break
                             size=size.replace('&nbsp;',' ')
                             size=size.replace('GiB','GB')
                             size=size.replace('MiB','MB')
                         
                             if '4k' in title:
                                  res='2160'
                             elif '2160' in title:
                                  res='2160'
                             elif '1080' in title:
                                  res='1080'
                             elif '720' in title:
                                  res='720'
                             elif '480' in title:
                                  res='480'
                             elif '360' in title:
                                  res='360'
                             else:
                                  res='HD'
                            
                             o_link=link
                           
                             try:
                                 o_size=size
                                 size=float(o_size.replace('GB','').replace('MB','').replace(",",'').strip())
                                 if 'MB' in o_size:
                                   size=size/1000
                             except Exception as e:
                                
                                size=0
                             max_size=int(Addon.getSetting("size_limit"))
                            
                             if size<max_size:
                               if allow_debrid:
                                    x=requests.get('https://www.torrentdownloads.me'+link,headers=base_header).content
                                    regex='"magnet(.+?)"'
                                    mm=re.compile(regex).findall(x)
                                    lk='magnet'+mm[0]
                               else:
                                    lk='https://www.torrentdownloads.me'+link
                               all_links.append((title,lk,'- Twor - '+str(size)+' GB'+' {P-%s/S-%s}'%(peer,seed),res))
                           
                               global_var=all_links
    return global_var
        
    