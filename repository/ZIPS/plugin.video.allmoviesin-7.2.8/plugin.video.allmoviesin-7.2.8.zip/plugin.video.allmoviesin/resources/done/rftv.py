# -*- coding: utf-8 -*-
#taken from Redflix tv apk
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['tv','movie']

import urllib2,urllib,logging,base64,json

color=all_colors[2]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    #import cfscrape
    all_links=[]
    
    url='http://redflixtv.me/api/search?api_secret_key=ssgx54x49bkv2xk7mkghksfz&q=%s&page=1'%(original_title)

    headers={
            'Connection': 'Keep-Alive',

            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; LS)'}
    progress='requests'
    x=requests.get(url,headers=headers).json()

    if tv_movie=='movie':
        ty='movie'
    else:
        ty='tvseries'
    for items in x[ty]:
            if items['title'].lower()!=clean_name(original_title,1).lower():
              continue
            
            if tv_movie=='movie':
                ur='http://redflixtv.me/api/get_single_details?api_secret_key=ssgx54x49bkv2xk7mkghksfz&type=movie&id='+items['videos_id']
            else:
                ur='http://redflixtv.me/api/get_single_details?api_secret_key=ssgx54x49bkv2xk7mkghksfz&type=tvseries&id='+items['videos_id']

            
            y=requests.get(ur,headers=headers).json()
           
            if tv_movie=='tv':
               for it in y['season']:
                
                if it['seasons_name'] ==season_n :
                    
                    for items2 in it['episodes']:
                        
                        if items2['episodes_name']==episode_n or items2['episodes_name'].lower()=='s%se%s'%(season_n,episode_n):
                            name1,match_s,res,check=server_data(items2['file_url'],original_title)
                            
                           
                            if check :
                                all_links.append((original_title,items2['file_url'],match_s,res))
                        
               check=False
            else:
                check=True
            if check:
              for items_in in y['videos']:
                
                    if '1080' in items_in['file_url']:
                        res='1080'
                    elif '720' in items_in['file_url']:
                        res='720'
                    elif '480' in items_in['file_url']:
                        res='480'
                    else:
                        res='720'
                    name1,match_s,res,check=server_data(items_in['file_url'],original_title)
                            
          
                    if check :
                        all_links.append((original_title,items_in['file_url'],'Direct',res))
            global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
            