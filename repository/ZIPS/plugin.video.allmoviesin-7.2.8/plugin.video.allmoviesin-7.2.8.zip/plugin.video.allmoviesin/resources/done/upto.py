# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json

rating=['External','uptobox']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
color=all_colors[71]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
  global global_var,stop_all,progress
  progress='Start'
  start_time=time.time()
  all_links=[]
  headers = {
    'Referer': 'http://uptoboxsearch.com/',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36',
  }
  progress='requests'
  x=requests.get('http://uptoboxsearch.com/',headers=headers).content
  regex="var cx = '(.+?)'"
  progress='Regex'
  match=re.compile(regex).findall(x)
  cx=match[0]
  progress='requests2'
  x=requests.get(domain_s+'cse.google.com/cse.js?cx='+cx).content
  regex='"cse_token": "(.+?)"'
  progress='Regex2'
  match=re.compile(regex).findall(x)
  cse=match[0]
  if tv_movie=='movie':
    q=(original_title.replace('%20',' '))
  else:
    q=(original_title.replace('%20',' ').replace('%27','')+' s'+season_n+' e'+episode_n)


  

  params = (
        ('rsz', 'filtered_cse'),
        ('num', '10'),
        ('hl', 'en'),
        ('source', 'gcsc'),
        ('gss', '.com'),

        ('cx', cx),
        ('q', q),
        ('safe', 'off'),
        ('cse_tok',cse),
        ('sort', ''),
        ('googlehost', 'www.google.com'),
        ('oq', 'rampage'),
       
        ('callback', 'google.search.Search.csqr6036'),
       
    )
  progress='requests3'
  html = requests.get('https://cse.google.com/cse/element/v1', headers=headers, params=params).content

    #NB. Original query string below. It seems impossible to parse and
    #reproduce query strings 100% accurately so the one below is given
    #in case the reproduced version is not "correct".
    # response = requests.get(domain_s+'www.googleapis.com/customsearch/v1element?key=AIzaSyCVAXiUzRYsML1Pv6RwSG1gunmMikTzQqY&rsz=filtered_cse&num=10&hl=en&prettyPrint=false&source=gcsc&gss=.com&sig=45e50696e04f15ce6310843f10a3a8fb&cx=004238030042834740991:-46442tgrgu&q=justice%20league%202017&cse_tok=AOdTmaC-ij38dzKkMq3QK2HyVv31W5gTHw:1520722941794&sort=&googlehost=www.google.com&oq=justice%20league%202017&gs_l=partner-generic.12...0.0.3.1622277.0.0.0.0.0.0.0.0..0.0.gsnos%2Cn%3D13...0.0jj1..1ac..25.partner-generic..36.5.239.zlYYXWhpZYw&callback=google.search.Search.apiary11806', headers=headers)

  regex='google.search.Search.csqr.+?\((.+?)\);'
  progress='Regex3'
  match=re.compile(regex,re.DOTALL).findall(html)

  j_res=json.loads(match[0])
  count=0
  
  for data in j_res['results']:
        progress='Links-'+str(count)
        count+=1
        title=data['titleNoFormatting']
        info=(PTN.parse(title.replace('..','.')))
        
        if 'resolution' in info:
          res=info['resolution']
        else:
          res=' '
        if 'http' not in data['url']:
          link_f='http://'+data['url']
        else:
          link_f=data['url']
        progress='requests-'+str(count)
        x=requests.get(link_f).content
        regex='<a href="https://uptostream.com/(.+?)"'
        match=re.compile(regex).findall(x)
        check=False
        if tv_movie=='movie':
            if show_original_year in title:
                check=True
        else:
            check=True
        if len (match)>0 and check:
            url=domain_s+'uptostream.com/'+match[0]

            all_links.append((title.replace("%20"," "),link_f,'Upto',res))
            global_var=all_links
  elapsed_time = time.time() - start_time
  progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
  return all_links