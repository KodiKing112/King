# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
global progress
progress=''
stop_all=0

rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['tv']

import urllib2,urllib,logging,base64,json

color=all_colors[105]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    base_link = 'http://watchtvseries.io'
                 
    search = '/?s='
    search_id = clean_name(original_title,1)+'+season+%s+episode+%s'%(season,episode)              
    c_search_id = clean_name(original_title,1)
    start_url = '%s%s%s' %(base_link,search,search_id.replace(' ','+'))



    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    #'Referer': 'https://watchtvseries.io/',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }

    progress='Cloud'
    x,cook= cloudflare_request(start_url,headers=headers)
    
    progress='requests'
    OPEN = requests.get(start_url,headers=headers,cookies=cook[0]).content

    progress='Regex'
    Regex = re.compile('class="item".+?<a href="(.+?)".+?alt="(.+?)"',re.DOTALL).findall(OPEN)

    for item_url,name in Regex:
        
        if stop_all==1:
            break
       

        seas=name.split('Season')[-1].split('Episode')[0].replace(' ','')

        epis=name.split('Episode')[-1].replace(' ','')

        name=name.split('Season')[0]




       
   
       
        if not c_search_id.lower() in name.lower():

            continue
        
        if not season == seas:

            continue
       
        if not episode == epis:

            continue
        progress='requests'
        OPEN = requests.get(item_url,headers=headers,cookies=cook[0]) .content
        
        id = re.compile('name="id" value="(.+?)"',re.DOTALL).findall(OPEN)[0]
     
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
            'Accept': '*/*',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Referer': item_url,
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'TE': 'Trailers',
        }

        params = (
            ('action', 'getvideo'),
            ('nb', ['0', '0']),
            ('b', [id, id]),
        )
        progress='requests2'
        response = requests.get('https://watchtvseries.io/wp-admin/admin-ajax.php', headers=cook[1], params=params,cookies=cook[0]).json()
        
       

        
        regex='<center><a href="(.+?)"'
        lk=re.compile(regex).findall(response['payload'])[0]
        
        progress='Check'
        name2,match_s,res,check=server_data(lk,original_title)
           
        if check:

            all_links.append((name2,lk,match_s,res))
            
            global_var=all_links
            
        params = (
            ('action', 'getvideo'),
            ('nb', ['2', '2']),
            ('b', [id, id]),
        )
        progress='requests3'
        response = requests.get('https://watchtvseries.io/wp-admin/admin-ajax.php', headers=cook[1], params=params,cookies=cook[0]).json()

        
        regex='<center><a href="(.+?)"'
        lk=re.compile(regex).findall(response['payload'])[0]
        
        progress='Check2'
        name2,match_s,res,check=server_data(lk,original_title)
        
        if check:
            
            all_links.append((name2,lk,match_s,res))
            
            global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links

