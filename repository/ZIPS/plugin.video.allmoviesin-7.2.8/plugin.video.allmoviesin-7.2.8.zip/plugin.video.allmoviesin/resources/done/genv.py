# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,logging
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,client,all_colors,res_q
type=['movie']

import urllib2,urllib,base64,json
color=all_colors[27]
def resolve_link(url):
  
    from jsunpack import unpack
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': url,
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    res = requests.post('https://vidlink.org/embed/update_views', headers=headers)
    cookies=res.cookies
    try:
        
        id_view=res.json()['id_view']
    except:
        id_view=''


    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
        'Accept': 'text/html, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': url,
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    data = {
      'browserName': 'Firefox',
      'platform': 'Win64',
      'postID': url.replace('https://vidlink.org/embed/','').replace('http://vidlink.org/embed/',''),
      'id_view': id_view
    }

    response = requests.post('https://vidlink.org/streamdrive/info', headers=headers, cookies=cookies, data=data).content
    holder=unpack(response)
    regex='window.srcs=(.+?);'
    match=re.compile(regex).findall(holder)

    results= json.loads(match[0])
    return results,cookies
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
       global global_var,stop_all,progress
       import cookielib,urlparse
       try: 
        progress='Start'
        start_time=time.time()
        from jsunpack import unpack
        all_links=[]
        User_Agent = 'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0'
        base_link = domain_s+'genvideos.com/'
        search_link = '/results?q=%s'
        url = domain_s+'genvideos.com/watch_%s_%s.html'%(clean_name(original_title,1).replace(' ','_').replace('-','_'),show_original_year)
        progress='request'
        html=client.request(url)
        
        step1=html.split('frame_url = "')
        varid=step1[1].split('"')[0]
        #regex='frame_url = "(.+?)"'
        
        progress='Regex -s'
        #varid=re.compile(regex).findall(html)[0]
        progress='Done Regex'
        varid = 'http:'+varid
        progress='request2'
        if varid=='http:':
            elapsed_time = time.time() - start_time
            progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
            return []
        get_info_html = requests.get(varid).content
        

      
        regex_d='<title>(.+?)</title>'
        progress='Regex'
        name_pre=re.compile(regex_d).findall(get_info_html)
        if len(name_pre)>0:
          name1=name_pre[0]
        else:
          name1=original_title
        
        #action = re.findall("'action': '(.+?)'",get_info_html)[0]
        
        headers={'User-Agent':User_Agent, 'referer':varid, 'X-Requested-With':'XMLHttpRequest','Host':'vidlink.org',
                 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
        data = {'browserName':'Firefox','platform':'Win64','postID':varid.replace('http://vidlink.org/embed/',''),
                }
        if not varid.startswith('https'):
            varid = varid.replace('http','https')

        links,cooki=resolve_link(varid)
        count=0
        for link in links:
            progress='Links-'+str(count)
            count+=1
            if stop_all==1:
                    break
            
            movie_link =  'https://vidlink.org'+(link['src'].replace('\/','/'))
        
       
            if '1080' in name1:
                res= '1080p'
            elif '720' in name1:
                res='720p'
            else:
                res='HD'
            progress='requests2-'+str(count)
            try:
                check_pre = requests.get(urllib.unquote_plus(movie_link),stream=True,timeout=5)
            except Exception as e:
                progress='Error-'+str(e)
            progress='Done requests2-'+str(count)
            f=check_pre.url
           
            check=check_pre.status_code
            if str(check) == '200' or str(check) == '301'or str(check) == '206': 
                parsed = urlparse.urlparse(f)
                f_link=urlparse.parse_qs(parsed.query)['url'][0]
                #head=urllib.urlencode(headers)
                #ht=requests.get(url,headers=headers).content
                progress='requests3-'+str(count)
                check_pre = requests.get(f_link,stream=True)
                
               
                check=check_pre.status_code
                if str(check) == '200' or str(check) == '301'or str(check) == '206':
                    all_links.append((name1.replace("%20"," "),f_link,'Googlelink',res))                
                    
                    global_var=all_links
                
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
            'Accept': 'text/html, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': varid,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
        progress='requests4-'
        x=requests.get(varid,headers=headers).content
        regex="postID = '(.+?)'"
        match=re.compile(regex).findall(x)[0]
        data = {
          'postID': match
        }
        progress='requests4-'
        response = requests.post('https://vidlink.org/opl/info', headers=headers, data=data,cookies=cooki).content
        try:
            response=json.loads(response)
            f_link=('https://openload.co/embed/'+response['id'])
            progress='Check-'
            name1,match_s,res,check=server_data(f_link,original_title)
      
            if check:
                all_links.append((name1.replace("%20"," "),f_link,match_s,res))                
                        
                global_var=all_links
        except:
            
            from jsunpack import unpack
            holder=unpack(response)
           
            regex='var playlist="(.+?)"'
            m=re.compile(regex).findall(holder)[0]
            f_link=('https://vidlink.org/hls/playlist/'+m)
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': varid,
                'Connection': 'keep-alive',
                'If-Modified-Since': 'Sun, 17 Mar 2019 09:12:28 GMT',
                'If-None-Match': '233-58446abc5d700',
            }

            head=urllib.urlencode(headers)
            f_link=f_link+"|"+head
            res=res_q(name1)
            all_links.append((name1,f_link,'Direct',res))                
                    
            global_var=all_links
    
 

        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links
       except Exception as e:
         import linecache,sys
         exc_type, exc_obj, tb = sys.exc_info()
         f = tb.tb_frame
         lineno = tb.tb_lineno
         filename = f.f_code.co_filename
         linecache.checkcache(filename)
         line = linecache.getline(filename, lineno, f.f_globals)
         
         