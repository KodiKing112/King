# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json



color=all_colors[67]
def resolve_streamm(links):


    headers = {
        'Referer': links,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
    }
    id=links.split('v=')[1]
    
    params = (
        ('v', id),
    )
    response = requests.get('http://streamm4u.ws/streamme/player.php', headers=headers, params=params).content
    print response

def resolve_m4u(links):
   
    headers = {
    'Pragma': 'no-cache',
    'Origin': 'http://them4ufree.com',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Cache-Control': 'no-cache',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Referer': links,
    }
    id=links.split('v=')[1]
    data = [
      ('v', id),
    ]

    response = requests.post('http://them4ufree.com/api-tt/playlist.php', headers=headers, data=data).content
    
    if 'playlist' not in response:
       return 'www'
    return response['playlist']
def resolve_openx_m4u(links):
    try:
        headers = {
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        }
        link=requests.get(links,headers=headers).url
        
        
              
    except:
      link=''
    return link
def get_new_links(token,url,cookies):


    
    
    headers = {
        'Pragma': 'no-cache',
        'Origin': 'http://ww1.m4ufree.com',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': '*/*',
        'Cache-Control': 'no-cache',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': url,
    }

    data = {
      'm4u':token
    }

    response = requests.post('http://ww1.m4ufree.com/ajax_new.php', headers=headers, data=data).content
    return response
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        progress='Start'
        start_time=time.time()
        title=original_title
        title=title.replace("%20",' ').replace('%3a',':').replace('%27',"'").replace("'",'').replace(".",'')
        year=show_original_year
        all_links=[]
        if tv_movie=='movies':
          search_string=title+' '+year
        else:
          search_string=title


        headers = {
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-US,en;q=0.9',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            #'Referer': domain_s+'m4ufree.com/',
            'Connection': 'keep-alive',
        }

        params = (
            ('keyword', search_string),
            ('search_section', '1'),
        )
        progress='Cloud'
        a,cook=cloudflare_request('http://ww1.m4ufree.com/watch-wa9o-rampage-2018-movie-online-free-m4ufree.html',headers=headers)
        progress='requests'
        response =requests.get(domain_s+'m4ufree.com/', headers=cook[1], params=params,cookies=cook[0]).content



        regex='<div class="item">.+?a href="(.+?)" title="(.+?)"'
        progress='Regex'
        match=re.compile(regex,re.DOTALL).findall(response)
        count=0
        for link,name in match:
          progress='Links-'+str(count)
          count+=1
          if stop_all==1:
                    break
          if tv_movie=='tv':

             if title.lower()==name.lower():
               f_link=link
               break
          elif title.lower() in name.lower() and year in name:
            f_link=link
            break

        f_link=f_link.replace("m4ufree.fun",'ww1.m4ufree.com')
        headers = {
            'Origin': domain_s+'www1.m4ufree.com',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-US,en;q=0.9',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': '*/*',
            'Referer': f_link,
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
        }
        progress='requests-'+str(count)
        response = requests.get(f_link,headers=cook[1],cookies=cook[0])
        
        res_cookies=response.cookies
        
        response=response.content
 
       # regex='csrf-token" content="(.+?)"'
       # key=re.compile(regex).findall(response)[0]
       
        if tv_movie=='tv':

          regex='idepisode="(.+?)" >S%s-E%s<'%(season_n,episode_n)
          progress='Regex-'+str(count)
          match=re.compile(regex).findall(response)
          headers = {
            'Origin': 'http://ww1.m4ufree.com',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': '*/*',
            'Referer': f_link.replace("./",domain_s+'ww1.m4ufree.com/'),
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
          }
          headers = {
                'Pragma': 'no-cache',
                'Origin': 'http://ww1.m4ufree.com',
                'Accept-Encoding': 'gzip, deflate',
                'Accept-Language': 'en-US,en;q=0.9',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Accept': '*/*',
                'Cache-Control': 'no-cache',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                #'Referer': 'http://ww1.m4ufree.com/watch-theflash-20846-tvshow-online-free-m4ufree.html',
          }
          data = [
            ('idepisode', match[0]),
            #('_token',key)
          ]
          progress='requests2-'+str(count)
          response = requests.post('http://ww1.m4ufree.com/ajax-tvshow.php',headers=headers,data=data,cookies=res_cookies).content

        
        regex='data="(.+?)"'
        progress='Regex2-'
        match=re.compile(regex).findall(response)
        count2=0
        for servers in match:
            progress='Regex2-'+str(count2)
            count2+=1
            response=get_new_links(servers,f_link,res_cookies)
         
            if stop_all==1:
                    break
         
            regex='<iframe.+?src="(.+?)"'
            progress='Regex3-'+str(count2)
            match2=re.compile(regex).findall(response)
           
            for links in match2:
               
               if stop_all==1:
                    break
               if 'streamm4u.' in links:
                links=resolve_streamm(links)
                
               if 'them4ufree' in links :
               
                 try:
                    links=resolve_m4u(links)
                 except:
                    continue
               if 'm4u1.openx.tv' in links:
                 links2=resolve_openx_m4u(links)
                 
                 all_links.append((original_title.replace("%20"," "),links2,'-Google-',' '))
               else:
                 if 'google' in links:
                    links=links.replace("preview","view")
                 progress='Check-'+str(count2)
                 name1,match_s,res,check=server_data(links,original_title)
                 
                 if check:
                    all_links.append((name1.replace("%20"," ").replace('@',''),links,match_s,res))
             
     
            global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links