# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
global progress
progress=''
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,get_vidcloud
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[108]

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    if tv_movie=='movie':
        search_url=clean_name(original_title,1)
    else:
        search_url=clean_name(original_title,1)+' season '+season
    all_links=[]
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }

    params = (
        ('keyword', search_url),
        ('id', '-1'),
    )
    progress='requests'
    response = requests.get('https://www8.watchmovie.io/ajax-search.html', headers=headers, params=params).json()
    regex='<li><a href="(.+?)" class="ss-title">(.+?)</a></li>'
    progress='Regex'
    match=re.compile(regex).findall(response['content'])
    count=0
    for link,title in match:
        progress=' Links - '+str(count)
        count+=1
        link='https://www8.watchmovie.io'+link
        if '(' in title:
            clear_name=title.split('(')[0].strip()
        else:
            clear_name=title.strip()
       
        check=False
        if tv_movie=='tv':
            logging.warning(clear_name)
            logging.warning(clean_name(original_title,1).lower().strip() +'Season '+season)
            if (clean_name(original_title,1).lower().strip() +' -Season '+season).lower().replace(' ','')== clear_name.lower().replace(' ','')  :
                check=True
        else:
            
            if clear_name.lower()==clean_name(original_title,1).lower().strip():
                
                check=True
        
        if check:
            if tv_movie=='tv':
                link=link+'/season'
                progress=' requests2 '+str(count)
                y=requests.get(link,headers=headers).content
                regex='<div class="vid_info"><span><a href="(.+?)" title="(.+?)"'
                
                match2=re.compile(regex).findall(y)
                
                f_link=False
                for links_in,titles in match2:
                    
                    if 'Season %s Episode %s-'%(season,episode) in titles:
                        f_link=links_in
                    
                        break
                    if 'Season %s Episode %s '%(season,episode) in titles:
                        f_link=links_in
                      
                        break
                    if 'season-%s-episode-%s'%(season,episode) in links_in:
                        f_link=links_in
                      
                        break
                if f_link:
                    
                    progress=' requests3 '+str(count)
                    z=requests.get('https://www8.watchmovie.io'+f_link,headers=headers).content
                    regex='data-video="(.+?)"'
                    links=re.compile(regex).findall(z)
                  
                    for lin in links:
                       
                       
                        if 'http' not in lin:
                            lin='http:'+lin
                        if 'vidcloud' in lin:
                            llin_s,hdr=get_vidcloud(lin)
                        else:
                            hdr=[]
                            llin_s=[lin]
                        for it in llin_s:
                            name1,match_s,res,check=server_data(it,original_title)
                            
                                      
                            if check :
                                if len(hdr)>0:
                                    head=urllib.urlencode(hdr)
                                    it=it+"|"+head
                                all_links.append((name1,it,match_s,res))
                                global_var=all_links
            else:
                progress=' requests4 '+str(count)
                y=requests.get(link,headers=headers).content
                regex='ul class="video_module">.+?<a href="(.+?)" class="view_more"></a>'
                ik=re.compile(regex,re.DOTALL).findall(y)[0]
                z=requests.get('https://www8.watchmovie.io'+ik,headers=headers).content
                regex='data-video="(.+?)"'
                links=re.compile(regex).findall(z)
                
                for lin in links:
                    if 'http' not in lin:
                        lin='http:'+lin
                    progress=' Check '+str(count)
                    if 'vidcloud' in lin:
                            llin_s=get_vidcloud(lin)
                    else:
                        llin_s=[lin]
                    for it in llin_s:
                        name1,match_s,res,check=server_data(it,original_title)
                                
                                  
                        if check :
                            all_links.append((name1,it,match_s,res))
                            global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
            
        
        
        
        
        
    