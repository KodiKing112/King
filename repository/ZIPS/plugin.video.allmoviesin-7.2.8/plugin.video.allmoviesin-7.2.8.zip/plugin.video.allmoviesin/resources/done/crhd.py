# -*- coding: utf-8 -*-
#taken from CARTOON HD movies
import requests,PTN

import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0
global progress
progress=''
rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,res_q
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[62]

def decrypt(ti,data_j):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': 'https://www.devglan.com/online-tools/aes-encryption-decryption',
        'Content-Type': 'application/json;charset=utf-8',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    data = {'textToDecrypt':data_j,
            'secretKey':ti,
            'mode':'ECB',
            'keySize':'128',
            'dataFormat':'Base64',
      
    }

    response = requests.post('https://www.devglan.com/online-tools/aes-decryption', headers=headers, json=data).json()
  
    try:
        return json.loads(response['output'].decode('base64'))
    except:
        return response['output'].decode('base64')
def decrypt_old(ti,data_j):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': 'https://www.tutorialspoint.com/compile_java_online.php',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Origin': 'https://www.tutorialspoint.com',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    quary='import java.text.DateFormat;\r\nimport java.text.SimpleDateFormat;\r\nimport java.util.ArrayList;\r\nimport java.util.Date;\r\nimport java.util.TimeZone;\r\nimport java.util.Base64;\r\nimport java.io.File;\r\nimport java.io.UnsupportedEncodingException;\r\nimport java.net.URLEncoder;\r\nimport java.security.MessageDigest;\r\nimport java.security.NoSuchAlgorithmException;\r\nimport java.util.Locale;\r\nimport java.security.Key;\r\nimport javax.crypto.Cipher;\r\nimport javax.crypto.spec.SecretKeySpec;\r\npublic class HelloWorld{\r\n    public static String m1344b(String str) {\r\n        String str2 = "MD5";\r\n        try {\r\n            MessageDigest instance = MessageDigest.getInstance("MD5");\r\n            instance.update(str.getBytes());\r\n            byte[] digest = instance.digest();\r\n            StringBuilder stringBuilder = new StringBuilder();\r\n            for (byte b : digest) {\r\n                str2 = Integer.toHexString(b & 255);\r\n                while (str2.length() < 2) {\r\n                    str2 = "0" + str2;\r\n                }\r\n                stringBuilder.append(str2);\r\n            }\r\n            return stringBuilder.toString();\r\n        } catch (NoSuchAlgorithmException e) {\r\n            e.printStackTrace();\r\n            return "";\r\n        }\r\n    }\r\n    \r\n    public static String m1280b(String str, String str2) {\r\n        byte[] bArr = null;\r\n        try {\r\n            Key secretKeySpec = new SecretKeySpec(str2.getBytes(), "AES");\r\n            Cipher instance = Cipher.getInstance("AES/ECB/PKCS5Padding");\r\n            instance.init(2, secretKeySpec);\r\n            bArr = instance.doFinal(Base64.getDecoder().decode(str.getBytes()));\r\n        } catch (Exception e) {\r\n            System.out.println(e.toString());\r\n        }\r\n        return new String(bArr);\r\n    }\r\n     public static void main(String []args){\r\n         String str = "",a="",b="",c="",d="";\r\n         \r\n    Date date = new Date();\r\n    DateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");\r\n    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Australia/Melbourne"));\r\n    a=new StringBuilder(String.valueOf(new Date(simpleDateFormat.format(date)).getTime())).toString().substring(0, 10);\r\n    a="";\r\n    System.out.println(a);\r\n   b="%s";\r\n    System.out.println(b);\r\n    \r\n    c="%s";\r\n    d=m1280b(c, b);\r\n    System.out.println("<Start>");\r\n    System.out.println(d);\r\n    System.out.println("<End>");\r\n     }\r\n}\r\n\r\n\r\n        '%(ti,data_j)
    data = {
      'lang': 'java',
      'device': '',
      'code': quary,
      'stdinput': '',
      'ext': 'java',
      'compile': 'javac',
      'execute': 'java -Xmx128M -Xms16M',
      'mainfile': 'HelloWorld.java',
      'uid': '7856897'
    }

    response = requests.post('https://tpcg.tutorialspoint.com/tpcg.php', headers=headers, data=data).content.replace('&gt;','>').replace('&lt;','<').replace("&quot;",'"')
    
    regex='<Start>(.+?)<End>'
    m=re.compile(regex,re.DOTALL).findall(response)
    try:
        return json.loads(m[0])
    except:
        return m[0]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    import hashlib 
    progress='Start'
    start_time=time.time()
    all_links=[]
    version='3.0.3'
    versioncode='303'
    ti=int(time.time())
    headers_p={'Content-Type': 'application/x-www-form-urlencoded',

            'Connection': 'Keep-Alive',
            'User-Agent': 'Apache-HttpClient/UNAVAILABLE (java 1.4)'}
    data={'option':'search',
    'os':'android',
    'q':original_title,
    'page':'1',
    'total':'0',
    'block':'0',
    'version':version,
    'versioncode':versioncode,
    'param_1':'1C799D6A874DD274CBD9B55B27E8F3A3',
    'deviceid':'',

    'access_token':'NDMyYzJjN2E5ZDBjZWFjYmVkNmUzNDZkMmE1ZjdlZTU%253D%250A',
    'time':ti}
            
    progress='requests'
    html=requests.post('http://funboxhd.com/gold-server/gapiandroid303/index2.php/?',headers=headers_p,data=data).json()

    data_j=html['data']
    ti_f=str(hashlib.md5("cthd" +str(ti)).hexdigest()) .lower()[0:16]
    progress='decrypt'
    result=decrypt(ti_f,data_j)
   
    for items in result['categories']:
        
        if clean_name(original_title,1).lower() in items['catalog_name'].lower() and show_original_year in items['catalog_name']:
            sid=str(hashlib.md5("content" + items['catalog_id'] + "cthd").hexdigest()) .lower()
           
            data={'option':'content',
            'os':'android',
            'id':items['catalog_id'],
            'sid':sid,
                   
            'version':version,
            'versioncode':versioncode,
            'param_1':'1C799D6A874DD274CBD9B55B27E8F3A3',
            'deviceid':'',

            'access_token':'NDMyYzJjN2E5ZDBjZWFjYmVkNmUzNDZkMmE1ZjdlZTU%253D%250A',
            'time':ti}
                    
            progress='requests2'
            html=requests.post('http://funboxhd.com/gold-server/gapiandroid303/index2.php/?',headers=headers_p,data=data).json()

            data_j=html['data']
            progress='decrypt2'
            result=decrypt(ti_f,data_j)
          
            for it in result['listvideos']:
                if tv_movie=='tv':
                    if 'S%sE%s'%(season_n,episode_n) not in it['film_name']:
                        continue
               
                sid=str(hashlib.md5(it['film_id'] + items['catalog_id'] + "cthd").hexdigest()) .lower()
                data={'option':'filmcontent',
                'os':'android',
                'id':it['film_id'],
                'sid':sid,
                       
                'version':version,
                'versioncode':versioncode,
                'param_1':'1C799D6A874DD274CBD9B55B27E8F3A3',
                'deviceid':'',

                'access_token':'NDMyYzJjN2E5ZDBjZWFjYmVkNmUzNDZkMmE1ZjdlZTU%253D%250A',
                'time':ti}
                        
                progress='requests3'
                html=requests.post('http://funboxhd.com/gold-server/gapiandroid303/index2.php/?',headers=headers_p,data=data).json()

                data_j=html['data']
                result=decrypt(ti_f,data_j)
                key=str(hashlib.md5(versioncode + version + "1C799D6A874DD274CBD9B55B27E8F3A3").hexdigest()) .lower()[5:21]
                
                progress='decrypt3'
          
                link=decrypt(key,result['videos'][0]['film_link']).replace('\n','')
                regex='http(.+?)#(.+?)#'
                links=re.compile(regex).findall(link)
                for link_in,q in links:
                    if 'http' not in link_in:
                        link_in='http'+link_in
                    all_links.append((original_title.replace("%20"," "),link_in,'Direct',q))
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
                    
        
           