# -*- coding: utf-8 -*-
import logging

import requests,re,PTN
import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,rd_domains,client,parseDOM
type=['movie','rd']

import urllib2,urllib,base64,json

color=all_colors[94]

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    base_link = 'https://ultrahdindir.com/'
    post_link = '/index.php?do=search'
    title = clean_name(original_title,1).replace(':','').lower()
    year = show_original_year

    query = '%s %s' % (title, show_original_year)
    query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

    url = urlparse.urljoin(base_link, post_link)
    
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://ultrahdindir.com/index.php?do=search',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    params = (
        ('do', 'search'),
    )

    data = [
      ('do', 'search'),
      ('subaction', 'search'),
      ('story', title+' '+year),
    ]

    r = requests.post('https://ultrahdindir.com/index.php', headers=headers, params=params, data=data).content
  
     
    regex='<div class="news-title"><a href="(.+?)">(.+?)<'
    match=re.compile(regex).findall(r)
    
    for link,name in match:
   
         
         if title.lower() in name.lower() :
          
          x=client.request(link)
          regex='div class="quote"><u><b><a href="(.+?)"'
          match_in=re.compile(regex).findall(x)
         
       
         
          for url in match_in:
               

               
                
                host = url.replace("\\", "")
                host2 = host.strip('"')
                host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(host2.strip().lower()).netloc)[0]
                
              
                if host not in rd_domains:
                    continue
                if '.iso' in url or '.rar' in url or '.zip' in url:
                    continue
               
                names=url.split('/')
                name1=names[len(names)-1]
                if '1080' in name1:
                      res='1080'
                elif '720' in name1:
                      res='720'
                elif '480' in name1:
                      res='480'
                elif '360' in name1:
                      res='360'
                else:
                      res='720'
          
                
                
                name1,match_s,res,check=server_data(url,original_title)
                if check :
                        if '.rar' not in name1:
                            all_links.append((name1,url,match_s,res))
                            global_var=all_links
       
    return global_var
  

   

   