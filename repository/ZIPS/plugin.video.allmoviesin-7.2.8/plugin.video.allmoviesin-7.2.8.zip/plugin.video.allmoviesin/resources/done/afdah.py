# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time

global global_var,stop_all#global
global progress
progress=''
global_var=[]

stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,res_q
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[5]
def resolve_link(url):
    global progress
    from jsunpack import unpack

    

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': url,
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    progress=' Reolve 1 '
    res = requests.post('https://vidlink.org/embed/update_views', headers=headers)
  
    res_h=unpack( res.content)
   
    cookies=res.cookies
    try:
        id_view=json.loads(res_h['id_view'])
    except:
        id_view=''


    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
        'Accept': 'text/html, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': url,
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    data = {
      'browserName': 'Firefox',
      'platform': 'Win64',
      'postID': url.replace('https://vidlink.org/embed/','').replace('http://vidlink.org/embed/',''),
      'id_view': id_view
    }
    progress=' Reolve 2 '
    response = requests.post('https://vidlink.org/streamdrive/info', headers=headers, cookies=cookies, data=data).content

    holder=unpack(response)
    regex='window.srcs=(.+?);'
    progress='Regex'
    match=re.compile(regex).findall(holder)

    results= json.loads(match[0])
    
   

    

    return results,cookies
   
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    import urlparse
    start_time=time.time()
    progress='Start'
    User_Agent = 'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0'
    all_links=[]
    session = requests.Session()
    base_link=domain_s+'putlockerhd.co'
    search_id = clean_name(original_title,1).lower()
    start_url = '%s/watch?v=%s_%s' %(base_link,search_id.replace(' ','_'),show_original_year)
    headers={'User-Agent':User_Agent}
    progress='Requests'
    html = requests.get(start_url,headers=headers).content
    varid = re.compile('var frame_url = "(.+?)"',re.DOTALL).findall(html)[0]
    
    if varid.startswith('"'):
        pass
    else:
        res_chk = re.compile('class="title"><h1>(.+?)</h1>',re.DOTALL).findall(html)[0]
        varid = 'http:'+varid
        
        progress='Requests - 2 '
        get_info_html = requests.get(varid,headers=headers).content
        progress='Regex_d'
        regex_d='<title>(.+?)</title>'
        name_pre=re.compile(regex_d).findall(get_info_html)
        if len(name_pre)>0:
          name1=name_pre[0]
        else:
          name1=original_title
        #action = re.findall("'action': '(.+?)'",get_info_html)[0]
        headers={'User-Agent':User_Agent, 'referer':varid, 'X-Requested-With':'XMLHttpRequest','Host':'vidlink.org',
                 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
        data = {'browserName':'Firefox','platform':'Win64','postID':varid.replace('http://vidlink.org/embed/',''),
                }
        if not varid.startswith('https'):
            varid = varid.replace('http','https')
        progress='Resolve'
        links,cooki=resolve_link(varid)
        
       
        count=0
        for link in links:
            progress='Links - '+str(count)
            count+=1
            if stop_all==1:
                break
            #link = link.replace('\\','').replace('/redirect?url=','')
            #movie_link = urllib.unquote(link.decode("utf8"))
            movie_link =  'https://vidlink.org'+(link['src'].replace('\/','/'))
            
            headers = {
                'authority': 'vidlink.org',
                'pragma': 'no-cache',
                'cache-control': 'no-cache',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                'accept-encoding': 'gzip, deflate, br',
                'accept-language': 'en-US,en;q=0.9',
                
            }
            if '1080' in res_chk:
                res= '1080p'
            elif '720' in res_chk:
                res='720p'
            else:
                res='HD'
            progress='Links Req - '+str(count)
            check_pre = requests.get(urllib.unquote_plus(movie_link),stream=True)
            f=check_pre.url
           
            check=check_pre.status_code
            if str(check) == '200' or str(check) == '301'or str(check) == '206': 
                parsed = urlparse.urlparse(f)
                f_link=urlparse.parse_qs(parsed.query)['url'][0]
                #head=urllib.urlencode(headers)
                #ht=requests.get(url,headers=headers).content
                
                check_pre = requests.get(f_link,stream=True)
                
                progress='Links Check - '+str(count)
                check=check_pre.status_code
                if str(check) == '200' or str(check) == '301'or str(check) == '206':
                    all_links.append((name1.replace("%20"," "),f_link,'Googlelink',res))                
                    
                    global_var=all_links
            
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
            'Accept': 'text/html, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': varid,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
        progress=' Req 2 '
        x=requests.get(varid,headers=headers).content
        regex="postID = '(.+?)'"
        match=re.compile(regex).findall(x)[0]
        data = {
          'postID': match
        }
        regex='title>(.+?)<'
        name1_p=re.compile(regex).findall(x)
        if len(name1_p)>0:
            name1=name1_p[0]
        else:
            name1=clean_name(original_title,1)
        progress=' Req 3 '
        response = requests.post('https://vidlink.org/opl/info', headers=headers, data=data,cookies=cooki).content
        try:
            response=json.loads(response)
            f_link=('https://openload.co/embed/'+response['id'])
            progress=' Check L '
            name1,match_s,res,check=server_data(f_link,original_title)
            
            if check:
                all_links.append((name1.replace("%20"," "),f_link,match_s,res))                
                        
                global_var=all_links
        except:
            
            from jsunpack import unpack
            holder=unpack(response)
           
            regex='var playlist="(.+?)"'
            m=re.compile(regex).findall(holder)[0]
            f_link=('https://vidlink.org/hls/playlist/'+m)
           
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': varid,
                'Connection': 'keep-alive',
                'If-Modified-Since': 'Sun, 17 Mar 2019 09:12:28 GMT',
                'If-None-Match': '233-58446abc5d700',
            }

            head=urllib.urlencode(headers)
            f_link=f_link+"|"+head
            res=res_q(name1)
            all_links.append((name1,f_link,'Direct',res))                
                    
            global_var=all_links
        
        
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
    