# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[44]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
 
    all_links=[]
    url='http://iwantmyshow.tk/'
    headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',

    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    html=requests.get(url,headers=headers).content
    
    regex='<p><a href="(.+?)"'
    base_link=re.compile(regex).findall(html)[0]
    if tv_movie=='tv':
      url=base_link+'/?s='+clean_name(original_title,1).replace(' ','+')+'+s'+season_n+'e'+episode_n
    else:
      url=base_link+'/?s='+clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
    headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',

    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    print url
    html=requests.get(url,headers=headers).content
    print url
    regex='"post-title"><a href="(.+?)".+?title="(.+?)"'
    match=re.compile(regex).findall(html)
  
    for link,name_in in match:
      if stop_all==1:
                    break
      if stop_all==1:
        break
      if clean_name(original_title,1).lower() in name_in.lower():
        y=requests.get(link+'2/',headers=headers).content
        regex='"entry-content"(.+?)</div>'
        match_in=re.compile(regex,re.DOTALL).findall(y)
        if len(match_in)>0:
          regex2='<li><a href="(.+?)"'
          match_l=re.compile(regex2,re.DOTALL).findall(match_in[0])
          for links in match_l:
            if stop_all==1:
                    break
            if stop_all==1:
                break
            resolvable=resolveurl.HostedMediaFile(links).valid_url()
            if resolvable:
                name1,match_s,res,check=server_data(links,original_title)
                    
                if check :
                  all_links.append((name1,links,match_s,res))
                  global_var=all_links
    return global_var