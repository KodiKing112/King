import requests,time,PTN
import unjuice
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors,base_header


import urllib2,urllib,logging,base64,json
color=all_colors[17]
type=['movie','tv']
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        all_links=[]
        start_time=time.time()
        if tv_movie=='movie':
            search_str=clean_name(original_title,1).lower() + ' '+show_original_year
        else:
            search_str=clean_name(original_title,1).lower() + ' S%s E%s '%(season_n,episode_n)
            
            
        headers = {
            'authority': 'p4pirate.xyz',
            'pragma': 'no-cache',
            'cache-control': 'no-cache',
            'origin': 'https://p4pirate.xyz',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36',
            'content-type': 'application/x-www-form-urlencoded',
            'accept': '*/*',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'referer': 'https://p4pirate.xyz/home/?q='+search_str.replace(' ','+'),
            'accept-encoding': 'utf-8',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            
        }

        params = (
            ('reason', 'show_results'),
        )

        data = {
          'q': search_str,
          'page': ''
        }

        x = requests.post('https://p4pirate.xyz/home/ajax.php', headers=headers, params=params, data=data).content
        
    
        #print x
        regex='<div class="card-body">(.+?)</div>\n</div>\n</div>'
        m_pre=re.compile(regex,re.DOTALL).findall(x)
        
        for items in m_pre:
            
            regex='"Responsive image">(.+?)<.+?data-src="(.+?)"'
            m=re.compile(regex,re.DOTALL).findall(items)
            regex='"Responsive image">(.+?)<.+?a target="_blank" href="(.+?)"'
            m2=re.compile(regex,re.DOTALL).findall(items)
           
            for nm,lk in m2+m:
                
                if tv_movie=='tv':
                    if 's%s e%s '%(season_n,episode_n) not in nm.lower():
                        continue
                
                if 'download' in lk:
                    
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Connection': 'keep-alive',
                        'Referer': 'https://p4pirate.xyz/home/index.php?q='+search_str,
                        'Upgrade-Insecure-Requests': '1',
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                    }

                    params = (
                        ('id', lk.split('id=')[1]),
                    )

                    response,cook= cloudflare_request('https://p4pirate.xyz/home/video2.php?id='+lk.split('id=')[1], headers=headers)
                    
                    regex="iframe.src = '(.+?)'"
                    m3=re.compile(regex,re.DOTALL).findall(response)
                    
                    f_link=m3[0]
                    if 'embed.php?id=' in f_link:
                        f_data=requests.get('https://p4pirate.xyz/home/'+f_link,headers=cook[1],cookies=cook[0]).content
                        
                        links = re.findall('sources: (\[\{.+?\}\])', f_data, re.DOTALL)[0]
                        links = json.loads(links)
                        for i in links:
                            if stop_all==1:
                                break
                            f_link = i['file']
                            qual = i['label']
                           
                            
                            
                            res=qual
                            
                            
                            all_links.append((nm,f_link,'Google',res))
                            global_var=all_links
                    elif 'feurl.com' in f_link:
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
                            'Accept': '*/*',
                            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'X-Requested-With': 'XMLHttpRequest',
                            'Origin': 'https://feurl.com',
                            'Connection': 'keep-alive',
                            'Referer':f_link,
                            'Pragma': 'no-cache',
                            'Cache-Control': 'no-cache',
                            'TE': 'Trailers',
                        }

                        data = {
                          'r': '',
                          'd': 'feurl.com'
                        }

                        response = requests.post(f_link.replace('https://feurl.com/v/','https://feurl.com/api/source/'), headers=headers,  data=data).json()
                   
                        for it in response['data']:
                            
                            res=it['label']
                            all_links.append((original_title,it['file'],'Direct',res))
                            global_var=all_links
                            
                    else:
                        name1,match_s,res,check=server_data(f_link,original_title)
                        
                        
                        if check :
                        
                            all_links.append((name1,f_link,match_s,res))
                            global_var=all_links
                else:
                 name1,match_s,res,check=server_data(lk,original_title)
                        
                        
                 if check :
                
                    all_links.append((name1,lk,match_s,res))
                    global_var=all_links
             
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links