# -*- coding: utf-8 -*-
#taken from silentghost 3 throw apk decompile
import requests
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors,res_q
type=['movie','tv']

import urllib2,urllib,logging,base64,json
color=all_colors[65]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        progress='Start'
        start_time=time.time()

   
        all_links=[]
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
            'Accept': 'text/plain, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
           
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

     
        progress='requests'
        
        response = requests.get('https://mindgeek.in/api/get_search_results1/?api_key=dda11uT8cBLzm6a1YvsiUWOEgrFowk95K2DM3tHAPRCX4ypGjN&search='+clean_name(original_title,1).replace(' ','%20'), headers=headers).json()
      
        for items in response['posts']:
            if clean_name(original_title,1).lower() in items['category_name'].lower() and 'hindi' not in items['category_name'].lower() and 'hindi' not in items['channel_name'].lower():
                if tv_movie=='tv':
                    id=items['category_id']
                    break
                else:
                    res=res_q(items['channel_name'])
                    nam1,srv,res2,check=server_data(items['channel_url'],original_title)
                         
                    if check:
                        all_links.append((items['category_name'],items['channel_url'],srv,res))
                        global_var=all_links
        if tv_movie=='tv':
            progress='requests2'
            x=requests.get('https://mindgeek.in/api/get_category_postsperseasonv2/?api_key=cda11uT8cBLzm6a1YvsiUWOEgrFowk95K2DM3tHAPRCX4ypGjN&season=%s&cid=%s'%(season,id), headers=headers).json()
            for items in x['posts']:
                
                if "Season %s - Episode %s"%(season,episode) in items['channel_name']:
                    res=res_q(items['channel_name'])
                    nam1,srv,res2,check=server_data(items['channel_url'],original_title)
                         
                    if check:
                        all_links.append((items['category_name'],items['channel_url'],srv,res))
                        global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return global_var