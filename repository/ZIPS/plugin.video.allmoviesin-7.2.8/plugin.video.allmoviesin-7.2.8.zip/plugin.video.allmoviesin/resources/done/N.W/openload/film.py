# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

rating=['External','uptobox']

color=all_colors[54]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    progress='requests'
    html=requests.get('http://filman.tv/?s=%s&searchsubmit.x=0&searchsubmit.y=0'%(clean_name(original_title,1).replace(" ","+")),headers=base_header).content
    regex='<h2 class="post-entry-headline"><a href="(.+?)">(.+?)</'
    progress='Regex'
    match=re.compile(regex).findall(html)
    count=0
    
    for link,name in match:
        progress='Links-'+str(count)
        count+=1
        if clean_name(original_title,1).lower() in name.lower() and show_original_year in name:
            y=requests.get(link,headers=base_header).content
            regex='<p><a class="button.+?" href="(.+?)"'
            m2=re.compile(regex).findall(y)
            for link_in in m2:
                progress='Check-'+str(count)
                name1,match_s,res,check=server_data(link_in,original_title)
                print link_in
                if check:
                      all_links.append((name1.replace("%20"," "),link_in,match_s,res))
                
                      global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
            
    
    
  