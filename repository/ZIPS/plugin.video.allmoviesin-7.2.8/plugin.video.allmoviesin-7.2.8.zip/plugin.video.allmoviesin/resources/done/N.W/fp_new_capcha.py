# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,os

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']
import Addon
import urllib2,urllib,logging,base64,json
dir_path =os.path.dirname(os.path.realpath(__file__))
mypath=os.path.join(dir_path,'cache_f')
servers_db=(os.path.join(mypath,'servers.db'))

try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database
color=all_colors[25]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
   
    all_links=[]



    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Linux; U; Android 4.4.2; zh-CN; HUAWEI MT7-TL00 Build/HuaweiMT7-TL00) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/40.0.2214.89 UCBrowser/11.3.8.909 Mobile Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    #base_url=scraper.get(domain_s+'filepursuit.com/search.php?search=zzzz',headers=headers).url
    base_url='https://filepursuit.com/pursuit?q=zzzz'

    if tv_movie=='tv':
      search_string=clean_name(original_title,1).replace(' ','+')+'+'+'s'+season_n+'e'+episode_n
    else:
      search_string=clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
    match_next=['0']
    dbconserver = database.connect(servers_db)
    dbcurserver = dbconserver.cursor()


    dbcurserver.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""speed TEXT);" % 'servers')
    dbcurserver.execute("VACUUM 'AllData';")
    dbcurserver.execute("PRAGMA auto_vacuum;")
    dbcurserver.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
    dbcurserver.execute("PRAGMA temp_store=MEMORY ;")
    dbconserver.commit()
    html,cook= cloudflare_request(domain_s+'filepursuit.com',headers=headers)
    print cook
    while len(match_next)>0:
        if stop_all==1:
             break
        s=base_url.replace('https://',domain_s).replace('zzzz',search_string).replace('zearch','search')
        #time.sleep(0.1)
        
        html= requests.get(domain_s+'filepursuit.com/pursuit?q=%s&type=video&startrow=%25s'%(search_string,match_next[0]),headers=cook[1],cookies=cook[0]).content
        #html=scraper.get(s,headers=headers)
        print domain_s+'filepursuit.com/pursuit?q=%s&type=video&startrow=%25s'%(search_string,match_next[0])
        regex='a href="/file/(.+?)">(.+?)<.+?</code>.+?<a href="(.+?)"'
        match=re.compile(regex,re.DOTALL).findall(html)
    
        try:
           max_size=int(Addon.getSetting("fp_size"))*1000000000
        except:
           max_size=3000000000
       
        for link,split_link,server in match:
           
            if stop_all==1:
                    break
            
            
           
            size_f='0'
            
            name1=split_link.replace('.mp4','').replace('.mkv','').replace('.avi','')
            regex='//(.+?)/'
            match_s=re.compile(regex).findall(server)[0]
            dbcurserver.execute("SELECT speed FROM servers WHERE name = '%s'"%(match_s))

            match = dbcurserver.fetchone()
            ok=0
            
            if match!=None:
       
              if match[0]!='TIMEOUT' and float(match[0])<0.6:
                ok=1
            else:
              ok=1
            if 'trailer' in name1.lower():
              ok=0
            if Addon.getSetting("filter_fp")=='false':
              ok=1
            if ok==1:
                if "1080" in link:
                  res="1080"
                elif "720" in link:
                  res="720"
                elif "480" in link:
                  res="720"
                elif "hd" in link.lower():
                  res="HD"
                else:
                 res=' '
                if match!=None:
                  try:
                    tt=str(float("{0:.2f}".format( float(match[0]))))
                  except:
                    tt=match[0]
                else:
                  tt=''
                if size_f!='0':
                  all_links.append((name1,'https://filepursuit.com/file/'+link,match_s+'[COLOR yellow] - '+size_f+'[/COLOR] - ' +tt,res))
                 
                else:
                    all_links.append((name1,'https://filepursuit.com/file/'+link,match_s+' - ' +tt,res))
                   
                global_var=all_links
               
        regex='type/video/startrow/(.+?)"><strong>Next'
        match_next=re.compile(regex).findall(html)
        
    return global_var
