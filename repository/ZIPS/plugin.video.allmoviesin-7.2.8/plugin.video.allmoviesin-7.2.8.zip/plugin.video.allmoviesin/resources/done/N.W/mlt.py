# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie','subs']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
import urllib2,urllib,logging,base64,json

color=all_colors[95]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    
    all_links=[]
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    }

    x,cook=cloudflare_request("http://www.multidown.me/?s="+clean_name(original_title,1).replace(' ','+'),headers=headers)
    regex_pre='div class="boximage2">(.+?)</div>'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(x)
    
  
    for items in match_pre:
        if stop_all==1:
                    break
        regex='<a href="(.+?)" rel="bookmark" title="(.+?)"'
        match=re.compile(regex).findall(items)
        
        for link,title in (match):
          if stop_all==1:
                    break
          if clean_name(original_title,1).lower() in title.lower() and show_original_year in title:
            y,cook=cloudflare_request(link,headers=headers)
            regex='<iframe src="(.+?)"'
            match2=re.compile(regex).findall(y)
            regex='<strong><a href="(.+?)" target="_blank" '
            match3=re.compile(regex).findall(y)
            for link in match2+match3:
                if stop_all==1:
                    break
                if 'cbox.ws' not in link and 'facebook' not in link and 'viewform' not in link:
                    
                    name1,match_s,res,check=server_data(link,original_title)
               
                                      
                    if check :
                        all_links.append((name1,link,match_s,res))
                        global_var=all_links
                        
    return global_var
        