# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[101]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    base_link = 'https://iwatchflix.xyz'
    movie_link = '/%s'
    tv_link = '/episode/%s-season-%s-episode-%s'
    url='https://www.iwatchflix.net/?s='+clean_name(original_title,1).replace(' ','+')
    r = client.request(url)
    print url
    regex='class="ml-item">.+?href="(.+?)".+?<h2>(.+?)<.+?rel="tag">(.+?)</'
    match = re.compile(regex,re.DOTALL).findall(r)
    f_link=''
    for link,name,year in match:
        if stop_all==1:
                    break
        if clean_name(original_title,1).lower() in name.lower() and show_original_year==year:
          f_link=link
          
    
    if f_link=='':
      return []
    r = client.request(f_link)
   
    match = re.compile('vidoza(.+?)"').findall(r)
    for url in match: 
        if stop_all==1:
            break
        url = 'https://vidoza%s' % url
        name1,match_s,res,check=server_data(url,original_title)
                    
                      
        if check :
            all_links.append((name1,url,match_s,res))
            global_var=all_links
    return global_var