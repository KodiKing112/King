import requests,re,time,PTN
import unjuice

global global_var,stop_all#global
global_var=[]
stop_all=0
type=['movie','tv']
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors


import urllib2,urllib,logging,base64,json

color=all_colors[4]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
  
        
        all_links=[]
        headers = {
            #'Host': 'putlockermovies.eu',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            #'Referer': 'putlockermovies.eu',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }

        response = requests.get('http://hushmovies.com/?s='+original_title.replace('%20','+').replace(' ','+').replace('%3a',':').replace('%27','+'), headers=headers).content
       
        regex='<div class="title"><a href="(.+?)">(.+?)<'
        match=re.compile(regex).findall(response)

        for link,name in match:
          if stop_all==1:
            break
          if  (original_title.lower().replace('%20',' ').replace('3a',':').replace('%27',"'")+' '+show_original_year) == name.replace("&#8217;","'").lower():

            
            
            if tv_movie=='tv':
              yy=requests.get(link+'?season='+season, headers=headers).content
              
              #regex='div class="numerando">%s - %s</div>.+?<div class="episodiotitle">.+?<a href="(.+?)">'%(season,episode)
              regex='Season %s Episode %s .+?"  href="(.+?)"'%(season,episode)
              regex_pre='<li>.+?</li>'
              match2_pre=re.compile(regex_pre).findall(yy)
              for items in match2_pre:
                  if stop_all==1:
                    break
                  regex='<a href="(.+?)">.+?<div class="numerando">%s - %s</div>'%(season,episode)
                  
                  match2=re.compile(regex).findall(items)
                  if len(match2)>0:
                    break
       
        
              zz=requests.get(match2[0]+'?watching', headers=headers).content
            else:
              yy=requests.get(link+'?watching', headers=headers).content
              zz=yy
              
       
            regex='class="metaframe rptss" src="(.+?)"'
            match3=re.compile(regex).findall(zz)
            
            '''
            xx=requests.get(domain_s+'putlockermovies.eu'+match3[0]).content
            regex='src="(.+?)"'
            match5=re.compile(regex).findall(xx)
            '''
            
            
            if 'show=' in match3[0]:
              links=match3[0].split('show=')[1].decode('base64')
              headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Referer': 'http://hushmovies.com'+match3[0],
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                }

              link = requests.get(links, headers=headers)
              
             
            name1,match_s,res,check=server_data(link.url,original_title)
            
            if check:
          
                  all_links.append((name1.replace("%20"," "),link.url,match_s,res))
                  global_var=all_links
        return all_links
