# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,urlparse
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[77]
def decode(x):

    count=1
    _ = ""
    r=0
    z="ZYX10+/PONM765LKJIAzyTSRQGxwvuHWVFEDUCBtsrqdcba9843ponmlkjihgfe2"
    while 1:
       
        
        tt=z.index(x[r])
       
        
        r+=1
        i= z.index(x[r])
        r+=1
     
        
        
        
        e=  (tt*4) | (i/16)
        
        
        o = z.index(x[r])
        r+=1
        b = ((15 & i) *16) | (o /4)
        
        a = z.index(x[r])
        r+=1
        t = ((3 & o) * 64) | (a)
     
        _ += chr(e)
        if o!=64:
            _ += chr(b)
        if a!=64:
            _ += chr(t)
        t=_
        
        
        if r>=len(x)-4:
           
            break 
        count+=1
    return _
def resolve_links(url,original_title,tv_movie,episode,base,dom):
    global global_var,stop_all,progress
    
    all_links=[]
   
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Origin': base,
        'Connection': 'keep-alive',
        'Referer': url+'/playtv',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

   

  
    params = (
        #('token', '154399880IZX4'),
        #('t', '1544016600'),
        #('k', '255057306'),
        #('v', 'static7.js'),
        ('no', '%s-%s'%(episode,episode)),
    )

    if tv_movie=='tv':
      response = requests.get('https://playtv.kotaksilver.casa', headers=headers, params=params).content
    else:
      response = requests.get('https://playmv.kotaksilver.casa', headers=headers,params=params).content
    
    

    code='''\
    var x="%s";
    var e, b, t, i, o, a, _ = "", r = 0;
    z="ZYX10+/PONM765LKJIAzyTSRQGxwvuHWVFEDUCBtsrqdcba9843ponmlkjihgfe2"
    for (x = x.replace(/[^A-Za-z0-9+\/=]/g, ""); r < x.length; )
        e = z.indexOf(x.charAt(r++)) << 2 | (i = z.indexOf(x.charAt(r++))) >> 4,
        b = (15 & i) << 4 | (o = z.indexOf(x.charAt(r++))) >> 2,
        t = (3 & o) << 6 | (a = z.indexOf(x.charAt(r++))),
        _ += String.fromCharCode(e),
        64 != o && (_ += String.fromCharCode(b)),
        64 != a && (_ += String.fromCharCode(t));
        result=_
    '''
    
    result2=decode(response)
    
    temp= (result2.encode('utf8', errors='ignore'))

    regex='"sources"(.+?)\],'

    m=re.compile(regex).findall(temp)
    for items in m:
        if stop_all==1:
            break
        j_data= json.loads('{"sources"'+items+']}')
        for data in j_data['sources']:
            progress='Check'
            name1,match_s,res,check=server_data(data['file'],original_title)
                         
                               
            if check :
                if 'rapidvideo' in data['file'] and 'www' not in data['file']:
                    data['file']=data['file'].replace('rapidvideo','www.rapidvideo')
                all_links.append((name1,data['file'],match_s,data['label']))
                global_var=all_links
    return global_var
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    base=requests.get('https://indoxx1.kim',headers=base_header)
    
    regex='var dom = "(.+?)"'
    dom=re.compile(regex).findall(base.content)[0]
    base=base.url
    base='https://idxx1.cam'
    logging.warning( base)
    progress='Start'
    start_time=time.time()
    all_links=[]
    imdb_id=""
    if season!=None and season!="%20":
       url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
    else:
     
       url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
    try:
       
        imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
        
    except Exception as e:
      
        return 0
    progress='requests'
   
    x=requests.get(base+'/s/'+imdb_id,headers=base_header).content
    regex="<div data-movie-id='(.+?)' class='ml-item'><a href='(.+?)' class='ml-mask jt' title='(.+?)'>"
    progress='Regex'
  
    match=re.compile(regex).findall(x)
   
    count=0
    for link,l,name in match:
        progress='Links-'+str(count)
        count+=1
        if stop_all==1:
            break
        check=False
        if tv_movie=='tv':
            if 'Season %s ('%season in name:
                check=True
        else:
          check=True
        if check:
          
          global_var= resolve_links(base+link,original_title,tv_movie,episode,base,dom)
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var