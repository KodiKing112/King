# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[88]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    import cfscrape
    all_links=[]
    base_link = 'https://moviefull-hd.org/'
    
    search_url = base_link + 'search/%s'
    #headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'}
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    if tv_movie=='tv':
      show_original_year=''
    search_id = urllib.quote_plus(original_title+' '+show_original_year).replace('+', '%2B')

    r = requests.get(search_url % search_id).content
  
    
    Regex = re.compile("suf-mosaic-post' href='(.+?)' title='(.+?)'").findall(r)
  
    for item_url, name in Regex:
        if stop_all==1:
            break
        check=False
        if tv_movie=='movie':
          if show_original_year in name:                                                           
            check=True
        else:
       
          if 'Season %s^'%season in name+'^':
            check=True
        
        if clean_name(original_title,1).lower() in clean_name(name,1).lower() and check:
            
            
            if tv_movie=='tv':
              item_url=item_url+episode
            headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
                       'Referer': item_url}
            r = requests.get(item_url, headers=headers).content

            link = re.compile('''<iframe.+?src=['"]([^'"]+)['"]''', re.DOTALL).findall(r)[0]
            count = 0
            print link
            html = requests.get(link, headers=headers).content
        
            juice = unjuice.run(str(html))
         
            links = re.findall('sources: (\[\{.+?\}\])', html, re.DOTALL)[0]
            links = json.loads(links)
            for i in links:
                if stop_all==1:
                    break
                url = i['file']
                qual = i['label']
                count += 1
                all_links.append((original_title,url+ '|Referer='+link,'direct',qual))
                global_var=all_links
    return global_var
    