# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header,res_q
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[91]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    import cfscrape
    all_links=[]
    url='http://dl8.lavinmovie.net/Movies/%s/'%show_original_year
    progress='requests'
    html=requests.get(url,headers=base_header).content
    title=clean_name(original_title,1).replace(' ','.')
    regex_string = r'href="{0}(.+?)"'.format(title)
    progress='Regex'
    results = re.compile(regex_string).findall(html)
    count=0
    
    for link in results:
        progress='Links-'+str(count)
        count+=1
        if 'Trailer' in link:
            continue
        if 'Dubbed' in link:
            continue
        url = 'http://dl8.lavinmovie.net/Movies/%s/'%show_original_year + title + link
       
        if '.zip' in url or '.rar' in url:
            continue
        res=res_q(url)
        all_links.append((original_title.replace("%20"," "),url,'Direct',res))
        global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
                