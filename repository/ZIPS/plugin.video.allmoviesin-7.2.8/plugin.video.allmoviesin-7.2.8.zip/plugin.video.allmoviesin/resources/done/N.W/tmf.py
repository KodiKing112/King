# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,rd_domains,parseDOM,client
type=['movie','tv','rd']

import urllib2,urllib,logging,base64,json

color=all_colors[92]
def getlinks( url):
        urls = []
        
        if 1:#try:
            if url is None: return
            r = client.request(url)
            r = parseDOM(r, 'div', attrs={'class': 'entry'})
            r = parseDOM(r, 'a', ret='href')
      
            r1 = [(i) for i in r if 'money' in i][0]
            r = client.request(r1)
            r = parseDOM(r, 'div', attrs={'id': 'post-\d+'})[0]
         
            if 'enter the password' in r:
                plink= parseDOM(r, 'form', ret='action')[0]

                post = {'post_password': '300mbfilms', 'Submit': 'Submit'}
                headers = {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive',
                   
                    'Pragma': 'no-cache',
                    
                    'Upgrade-Insecure-Requests': '1',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                }
                send_post = requests.post(plink,headers=headers, data=post).cookies
     
                link = client.request(r1, cookie=send_post)
               
            else:
                link = client.request(r1)

            link = re.findall('<strong>Single(.+?)</tr', link, re.DOTALL)[0]
            link = parseDOM(link, 'a', ret='href')
            link = [(i.split('url=')[-1]) for i in link]
            for i in link:
                if 'earn-money-onlines' in i:
                    y=requests.get(i,headers=headers).content
                    regex='center> <a href="(.+?)"'
                    i2=re.compile(regex).findall(y)[0]
                else:
                    i2=i
                
                urls.append(i2)

            return urls
        #except:
        #    pass
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    base_link = 'https://www.300mbfilms.co/'
    search_link = '/search/%s/feed/rss2/'
    title =clean_name(original_title,1)
    
    if tv_movie=='tv':
        query = '%s S%sE%s' % (title, season_n, episode_n) 
    else:
        query ='%s %s' % (title, show_original_year)
    if tv_movie=='tv':
       hdlr = 'S%sE%s' % (season_n, episode_n)
    else:
       hdlr = show_original_year
    
    url = search_link % urllib.quote_plus(query)
    url = urlparse.urljoin(base_link, url)
    headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
           
            'Pragma': 'no-cache',
            
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        }
    r = requests.get(url,headers=headers).content
 
    posts = parseDOM(r, 'item')

  
    items = []

    for post in posts:
        try:
            t = parseDOM(post, 'title')[0]
            u = parseDOM(post, 'link')[0]
            s = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', t)
            s = s[0] if s else '0'

            items += [(t, u, s) ]

        except:
            pass

    urls = []
    for item in items:
        
        if clean_name(original_title,1).lower() in item[0].lower() and hdlr in item[0]:
                    
                    links = getlinks(item[1])
                    for url in links:
                        
                        if 'http' not in url:
                            continue
                        host = url.replace("\\", "")
                        host2 = host.strip('"')
                        host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(host2.strip().lower()).netloc)[0]
                      
                        if host not in rd_domains:
                            continue
                        if '.iso' in url or '.rar' in url or '.zip' in url:
                            continue
                        names=url.split('/')
                        name1=names[len(names)-1]
                        if '1080' in name1:
                              res='1080'
                        elif '720' in name1:
                              res='720'
                        elif '480' in name1:
                              res='480'
                        elif '360' in name1:
                              res='360'
                        else:
                              res='720'
                  
                        #name1,match_s,res,check=server_data(link,original_title,direct='rd')
                        if clean_name(original_title,1).lower() in name1.lower().replace('.',' '):
                            check=True
                        else:
                            check=False
                        if 'openload' in url or 'streamango' in url:
                             name1,match_s,res,check=server_data(url,original_title)
        
                        if check :
                               
                                    all_links.append((name1,url,match_s,res))
                                    global_var=all_links
                            
    return global_var
          