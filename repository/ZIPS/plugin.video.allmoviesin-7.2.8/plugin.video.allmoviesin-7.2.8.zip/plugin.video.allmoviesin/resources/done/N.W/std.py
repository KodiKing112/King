# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[89]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    import cfscrape
    all_links=[]
    base_link = 'https://streamango.stream/'
    
    search_url = base_link + 'search/%s'
    #headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'}
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    search_id = clean_name(original_title.lower(),1)                                      
    start_url = '%s?s=%s' %(base_link,search_id.replace(' ','+'))         
                               
    print start_url
    html,cook = cloudflare_request(start_url)           
    print 'done'
    #html=requests.get(start_url,headers=headers,cookies=cook[0]).content
    match = re.compile('<li class="TPostMv".+?class="TPMvCn">.+?<a href="(.+?)"><div class="Title">(.+?)</div></a>.+?class="Date">(.+?)</span><span class="Qlty">(.+?)</span>',re.DOTALL).findall(html) 
   
    for item_url, name, date, res in match:
        
        if show_original_year in date:                                                           
            if clean_name(search_id,1).lower() in clean_name(name,1).lower():       
             
                OPEN = requests.get(item_url,headers=cook[1],cookies=cook[0]).content
                Endlinks = re.compile('TrvideoFirst\">(.+?)</div>',re.DOTALL).findall(OPEN)
                #print 'scraperchk - scrape_movie - EndLinks: '+str(Endlinks)
                for link2 in Endlinks:
                    #print 'scraperchk - scrape_movie - link: '+str(link2)        
                    link1=base64.b64decode(link2)
                    #print link1+'decoded?????????????????????????????????????????'
                    Endlink =link1.split('src=')[1].split('allowfullscreen')[0].replace('"','').rstrip()
                    #print Endlink +'<<<<<<<<<<<<<<<<endlink>>>>>>>>>>>>>>'
                    if 'openlinks' in Endlink:
                        
                        OPEN = requests.get(Endlink,headers=cook[1],cookies=cook[0],allow_redirects=True).content
                        finalurl = re.compile('url\" content="(.+?)">',re.DOTALL).findall(OPEN)
                        for link in finalurl:
           
                            name1,match_s,res,check=server_data(link,original_title)
                        
                          
                            if check :
                                all_links.append((name1,link,match_s,res))
                                global_var=all_links
    return global_var