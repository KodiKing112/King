# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[66]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    if tv_movie=='tv':
      
      url='http://realtalksociety.com/?search='+(original_title.replace("%20",".").replace(" ","%20").replace("%27","")+'%20'+'s%se%s'%(season_n,episode_n))
    else:
      url='http://realtalksociety.com/?search='+(original_title.replace("%20",".").replace(" ","%20").replace("%27",""))
    print url
    headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',

    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    html=requests.get(url,headers=headers).content
    
    regex='videos_id=".+?" href="(.+?)" title="(.+?)"'
    match=re.compile(regex).findall(html)
    all_link_a=[]
    
    for link,name in match:
       
        if stop_all==1:
           break
        check=False
        if tv_movie=='tv':
        
         if ('.S%sE%s.'%(season_n,episode_n)).lower() in name.lower() or (' S%sE%s '%(season_n,episode_n)).lower() in name.lower():
           check=True
        else:
           check=True

        if clean_name(original_title,1).lower().replace(" ",".") in name.lower().replace(" ",".") and check==True:
            print name
            x=requests.get(link,headers=headers).content

            regex='<source src="(.+?)"'
            match2=re.compile(regex).findall(x)
            if match2[0] not in all_link_a:
              all_link_a.append(match2[0])
              try_head = requests.get(match2[0],headers=base_header, stream=True,verify=False,timeout=10)
              f_size2='0.0 GB'

              if 'Content-Length' in try_head.headers:
                   if int(try_head.headers['Content-Length'])>(1024*1024):
                    f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
              if f_size2!='0.0 GB':
                    s_name='Direct'+' - '+f_size2
              else:
                    s_name='Direct'
              all_links.append((name,match2[0],s_name,'720'))
              global_var=all_links
    return global_var
    