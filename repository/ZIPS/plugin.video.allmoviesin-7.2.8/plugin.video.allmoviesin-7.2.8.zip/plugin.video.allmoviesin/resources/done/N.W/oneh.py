# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[100]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    url='http://bbplayer.one/openmovs/?DA'
    
    x,cook=cloudflare_request(url)
    
    regex='<a href="(.+?)">(.+?)<'
 
    m=re.compile(regex,re.DOTALL).findall(x)
    
    for lk,nm in m:
        if stop_all==1:
            break
        if '.mp4' not in lk and '.mkv' not in lk:
            continue
        if '4k' in lk:
              res='2160'
        elif '2160' in lk:
              res='2160'
        elif '1080' in lk:
              res='1080'
        elif '720' in lk:
              res='720'
        elif '480' in lk:
              res='480'
        elif '360' in lk:
              res='360'
        else:
              res='720'
        print nm.lower()
        if clean_name(original_title,1).lower() not in nm.lower():
            continue
        try_head = requests.head('http://bbplayer.one'+lk,headers=base_header, stream=True,verify=False,timeout=15)
        
        size='0'
        if 'Content-Length' in try_head.headers:
          
                if int(try_head.headers['Content-Length'])>(1024*1024):
                    f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                if f_size2!='0.0 GB':
                    size=f_size2
                else:
                    size='0'
        
        
        t=lk.split('/')
        title=t[len(t)-1].replace('/','')
        all_links.append((nm,'http://bbplayer.one'+lk,'- Direct - '+str(size),res))
                       
        global_var=all_links
    return global_var