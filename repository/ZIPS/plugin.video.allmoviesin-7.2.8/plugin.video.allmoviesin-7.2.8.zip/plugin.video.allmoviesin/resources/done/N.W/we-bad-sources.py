# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv']

rating=['External','All']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[75]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all

        title=original_title
        f_link=''
        if tv_movie=='tv':
            link='http://www.watchepisodes4.com/'+(title.lower().replace('%20','-').replace('%3a','').replace(' ','-'))
            
              
           
              
            print link
            x=requests.get(link).content
            regex='href="(.+?)"'
            
            response2=re.compile(regex).findall(x)
            for li in response2:
             
              if 'season-%s-episode-%s-'%(season,episode) in li:
                f_link=li
                break
            if len(f_link)>0:
                x=requests.get(f_link).content
                regex='class="watch-button" data-actuallink="(.+?)"'
                response2=re.compile(regex).findall(x)
                all_links=[]
                
                for links in response2:
                  if stop_all==1:
                    break
                  if 1:#try:
                    if 'streamvid' in links:
                        x=client.request(links)
                        regex='<div id="video_player">(.+?)</script>'
                        m=re.compile(regex,re.DOTALL).findall(x)
                        juice = unjuice.run(str(m[0]))
                      
                        links = re.findall('sources:(\[\{.+?\}\])', juice, re.DOTALL)[0]
                        links = json.loads(links)
                        for i in links:
                            if stop_all==1:
                                break
                            url = i['file']
                            qual = i['label']
                            
                            all_links.append((original_title,url+ '|Referer='+links,'direct',qual.replace('HD','720')))
                            global_var=all_links
                    else:
                       resolvable=resolveurl.HostedMediaFile(links).valid_url()
                       if resolvable:
                            links=links.replace('openload.io','openload.co')
                            name1,match_s,res,check=server_data(links,original_title)
                            if check:
                              all_links.append((name1.replace("%20"," ").replace('\n','').replace('\t',''),links,match_s,res))
                              global_var=all_links
              #except:
              #  pass
        return global_var
        