# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,client,cleantitle,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
import urllib2
import cookielib

color=all_colors[8]

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
        all_links=[]
        

        
    
        base_link = domain_s+'azmovies.xyz/'
        search_link = '/search.php?q=%s'
        url = urlparse.urljoin(base_link, search_link)
        url = url  % (clean_name(original_title,1).replace(':', ' ').replace(' ', '+'))
        
        
        
        cookies = cookielib.LWPCookieJar()
        handlers = [
            urllib2.HTTPHandler(),
            urllib2.HTTPSHandler(),
            urllib2.HTTPCookieProcessor(cookies)
            ]
        opener = urllib2.build_opener(*handlers)
        opener.addheaders = [('User-agent', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0')]
        

        uri = url
        req = urllib2.Request(uri)
        res=opener.open(req)
        cookies_f={}
        for cookie in cookies:
                cookies_f[cookie.name]= cookie.value
        


       
        html= res.read()
        
        #search_results = client.request(url,cookie=cookies)
        regex='document.cookie = "(.+?)=(.+?)"'
        match=re.compile(regex).findall(html)
       
        for ck in match:
            cookies_f[ck[0]]=ck[1]
      
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
            'Accept': '*/*',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Referer': 'https://azmovie.to/',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'TE': 'Trailers',
        }

        data = {
          'searchVal': 'rampage'
        }

        search_results = requests.post('https://azmovie.to/livesearch.php', headers=headers, cookies=cookies_f, data=data).content

        
        
        #search_results =client.request(url,cookie=cookies_f)
        
        match = re.compile("<a href='(.+?)'.+?class='left'>(.+?)<br>",re.DOTALL).findall(search_results)
        
        for item_url,item_title in match:
            
            if stop_all==1:
                break
            if cleantitle.get(original_title).lower() in cleantitle.get(item_title).lower():
                item_url = urlparse.urljoin(base_link, item_url)
                html = client.request(item_url,cookie=cookies_f)
                date = re.compile('Release:(.+?)<br>',re.DOTALL).findall(html)[0]
                if show_original_year in str(date):
                    html = client.request(item_url,cookie=cookies_f)
                    regex_q='ame="keywords" content="(.+?)"'
                    match_q = re.compile(regex_q).findall(html)[0]
                    match = re.compile("<ul id='serverul'(.+?)</ul>",re.DOTALL).findall(html)
                    Links = re.compile('<a href="(.+?)"',re.DOTALL).findall(str(match))
                    
                    for link in Links:
                            link = urlparse.urljoin(base_link, link)
                            if stop_all==1:
                                break
                            if '1080' in match_q:
                                quality = '1080p'
                            elif '720' in match_q:
                                quality='720p'
                            else:
                                quality='SD'
                            host = link.split('//')[1].replace('www.','')
                            host = host.split('/')[0].split('.')[0].title()
                            
                            if 'openload' in link or 'streamango' in link:
                               name1,match_s,res,check=server_data(link,original_title)
                               if check:
                                  all_links.append((name1.replace("%20"," "),link,match_s,res))
                                  global_var=all_links
                            else:
                                headers = {
                                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                    'Accept-Language': 'en-US,en;q=0.5',
                                    'Referer': item_url,
                                    'Connection': 'keep-alive',
                                    'Upgrade-Insecure-Requests': '1',
                                    'Pragma': 'no-cache',
                                    'Cache-Control': 'no-cache',
                                    'TE': 'Trailers',
                                }
                                
                                response = requests.get(link, headers=headers).content
                               
                                regex="src: '(.+?)'"
                                match=re.compile(regex).findall(response)[0]
                                
                                
                                all_links.append((original_title.replace("%20"," "),'https://files.azmovies.co/'+match,host,quality))
                                global_var=all_links
                           