# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie','tv','subs']

import urllib2,urllib,logging,base64,json

color=all_colors[95]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    o_name=name
    progress='Start'
    start_time=time.time()
    all_links=[]
    headers = {
    'Referer': 'https://serethd.net',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36',
    }
    progress='requests'
    x=requests.get('https://serethd.net',headers=headers).content
    regex="var cx = '(.+?)'"
    progress='Regex'
    match=re.compile(regex).findall(x)
    cx=match[0]
    progress='requests2'
    x=requests.get(domain_s+'cse.google.com/cse.js?cx='+cx).content
    regex='"cse_token": "(.+?)"'
    match=re.compile(regex).findall(x)
    cse=match[0]
    if tv_movie=='movie':
        q=(original_title.replace('%20',' ')+' '+show_original_year)
    else:
        q=(original_title.replace('%20',' ').replace('%27',''))




    params = (
        ('rsz', 'filtered_cse'),
        ('num', '10'),
        ('hl', 'en'),
        ('source', 'gcsc'),
        ('gss', '.com'),

        ('cx', cx),
        ('q', q),
        ('safe', 'off'),
        ('cse_tok',cse),
        ('sort', ''),
        ('googlehost', 'www.google.com'),
        ('oq', 'rampage'),
       
        ('callback', 'google.search.Search.csqr6036'),
       
    )
    progress='requests3'
    x = requests.get('https://cse.google.com/cse/element/v1', headers=headers, params=params).content
  
    regex='google.search.Search.csqr.+?\((.+?)\);'
    progress='Regex2'
    match=re.compile(regex,re.DOTALL).findall(x)

    j_res=json.loads(match[0])

  
    count=0
    for data in j_res['results']:
        progress='Links-'+str(count)
        count+=1
        name=data['titleNoFormatting']
        link=data['url']
        
    
        
        check=False
        if tv_movie=='movie':
           
            if show_original_year in data['content']:
                check=True
        else:
           
           if '-%s-'%season in link:
             check =True
             
            
        
       
        if check:
            
            
            link=urllib.unquote_plus(link)
            progress='requests-'+str(count)
            y=requests.get(link,headers=headers).content
            regex='class="ml-item">.+?a href="(.+?)"'
            mm=re.compile(regex,re.DOTALL).findall(y)
            progress='requests2-'+str(count)
            y=requests.get(mm[0],headers=headers).content
            
            if tv_movie=='tv':
                
                regex='<a class="tab.+?" href="(.+?)".+?>פרק %s <'%episode
                
                m=re.compile(regex).findall(y)
                
                if len(m)==0:
                    regex='<p>פרק {0}</p>(.+?)<hr />'.format(episode)
                    mm2=re.compile(regex,re.DOTALL).findall(y)
             
                    if len(mm2)>0:
                        regex='href="(.+?)"'
                        f_links=re.compile(regex,re.DOTALL).findall(mm2[0])
                       
                        
                        for link in f_links:
                            progress='Check-'+str(count)
                            name1,match_s,res,check=server_data(link,original_title)
                            if check :
                                all_links.append((name1,link,match_s,res))
                                global_var=all_links
                else:
                  
                  for items in m:
                    if 'iframe class=' in items:
                        regex='iframe class=(?:\'|")%s_iframe(?:\'|") data-src="(.+?)"'%items
                        mm=re.compile(regex).findall(y)
                        for link in mm:
                    
                            
                            if 'serethd.net' in link:
                                z=requests.get(link,headers=headers).content
                                regex='file: "(.+?)"'
                                link_p=re.compile(regex).findall(z)
                                if len(link_p)>0:
                                    link=link_p
                                    name1,match_s,res,check=server_data(link,original_title)
                                    if check :
                                        all_links.append((name1,link,match_s,res))
                                        global_var=all_links
                                else:
                                    from jsunpack import unpack
                                    regex='type="text/javascript">(.+?)</script>'
                                    jm=re.compile(regex,re.DOTALL).findall(z)[1]
                                    
                                    holder=unpack(jm)
                                    regex='"label":"(.+?)".+?"file":"(.+?)"'
                                    lk=re.compile(regex,re.DOTALL).findall(holder)
                                
                                    for res,link in lk:
                                        if res=='HD':
                                            res='720'
                                        elif res=='SD':
                                            res='480'
                                        
                                        all_links.append((original_title,link,'Direct',res))
                                        global_var=all_links
                            else:
                                progress='check3-'+str(count)
                                name1,match_s,res,check=server_data(link,original_title)
                                if check :
                                    all_links.append((name1,link,match_s,res))
                                    global_var=all_links
                    else:
                        progress='check2-'+str(count)
                        name1,match_s,res,check=server_data(items,original_title)
                        if check :
                            all_links.append((name1,items,match_s,res))
                            global_var=all_links
            else:
                regex='<div class="les-content"><a href="(.+?)"'
                match=re.compile(regex).findall(y)
              
                for link in match:
                    
                    
                    if 'serethd.net' in link:
                        progress='requests3-'+str(count)
                        z=requests.get(link,headers=headers).content
                        regex='file: "(.+?)"'
                        link_p=re.compile(regex).findall(z)
                        if len(link_p)>0:
                            link=link_p
                        
                    progress='check4-'+str(count)
                    name1,match_s,res,check=server_data(link,original_title)
                    if check :
                        all_links.append((name1,link,match_s,res))
                        global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var