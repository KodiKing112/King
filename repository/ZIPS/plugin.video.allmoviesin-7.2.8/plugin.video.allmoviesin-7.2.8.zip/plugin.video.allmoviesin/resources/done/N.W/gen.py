# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request
type=['movie']

import urllib2,urllib,logging,base64,json

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
        all_links=[]
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
          
            'Pragma': 'no-cache',
       
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        }
        url='http://genietvcunts.co.uk/PansBox/ORIGINS/Movies/genres/Action.php'
        html=requests.get(url,headers=headers).content
        regex='<a href="(.+?)".+?<br><b>(.+?)<'
        match=re.compile(regex).findall(html)
        all_links_in=[]
        for link,name_in in match:
          if clean_name(original_title,1).lower() in name_in.lower() and '_CAM' not in link :
             if '1080' in name_in:
              res='1080'
             elif '720' in name_in:
              res='720'
            
             elif '480' in name_in:
              res='480'
             else:
              res='HD'
             ids=link.split('/')
             name1=ids[len(ids)-1]
             if link not in all_links_in:
               all_links_in.append(link)
               all_links.append((name1.replace("%20"," "),link,'Direct',res))
               global_var=all_links 
        return global_var