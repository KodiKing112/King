# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,sys,os

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[83]

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    
    dir_path = os.path.dirname(os.path.realpath(__file__))
    mypath=os.path.join(dir_path,'..\solvers')
    sys.path.append(mypath)

    from play import search
    
    if tv_movie=='movie':
      
      imdbid_data=domain_s+'api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0'%id
      
      x=requests.get(imdbid_data).json()
      imdbid=x['imdb_id']
     
      info={'search': 'movie', 'title': clean_name(original_title,1).replace("'",''), 'year': show_original_year, 'imdb_id':imdbid}
    else:
       imdbid_data=domain_s+'api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'%id
      
       x=requests.get(imdbid_data).json()
       imdbid=x['external_ids']['imdb_id']
       info={'season': season, 'search': 'episode', 'title': clean_name(original_title,1).replace("'",''), 'episode': episode, 'imdb_id': imdbid}

    imdb_global=imdbid

    results=(search(info))
    
    global_var=results
    return global_var