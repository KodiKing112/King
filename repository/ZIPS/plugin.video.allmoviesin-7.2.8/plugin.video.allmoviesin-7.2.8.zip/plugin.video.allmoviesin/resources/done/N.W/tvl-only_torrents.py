# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','subs']

import urllib2,urllib,logging,base64,json

color=all_colors[69]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    
    all_links=[]
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        #'Host': 'www.tvil.me',
        'Pragma': 'no-cache',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'X-Requested-With': 'XMLHttpRequest',
    'Alt-Used': 'www.tvil.nl:443',
    'Connection': 'keep-alive',
    'TE': 'Trailers',
    }

    params = (
        ('action', 'typeahead'),
        ('do', 'shows'),
        ('q', clean_name(original_title,1)),
    )

    html = requests.get('http://www.tvil.nl/php_ajax.php', headers=headers, params=params).json()
   
    regex="<span class='typeahead-result' data-id='(.+?)' data-engname='(.+?)'>(.+?)<"
    match=re.compile(regex).findall(html[0].encode('utf-8'))
    
    for id,link,title_o in match:
            
            if stop_all==1:
                    break
            headers = {
                'Pragma': 'no-cache',
                'Origin': 'http://www.tvil.nl',
                'Accept-Encoding': 'utf8',
                'Accept-Language': 'en-US,en;q=0.9',
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Accept': '*/*',
                'Cache-Control': 'no-cache',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                'Referer': 'http://www.tvil.nl/streamOn/'+id+'/'+link,
            }

            data = {
              'showID': id,
              'season': season,
              'episode': episode,
              'q': '480',
              'src': '',
              'special': '1'
            }

            response = requests.post('http://www.tvil.nl/ajax/episodes/player', headers=headers, data=data).content
      
            
            regex='src: "(.+?)"'
            m=re.compile(regex).findall(response)[0]
            headers = {
                'Referer': 'http://www.tvil.nl/streamOn/'+id+'/'+link,
                'Accept-Encoding': 'identity;q=1, *;q=0',
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36',
                'Range': 'bytes=0-',
            }
            head=urllib.urlencode(headers)
            m=m+"|"+head
            all_links.append((original_title,m,'Direct',' '))
            global_var=all_links

           
        
    return global_var
    