import requests,re
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors,cloudflare_request
type=['movie','tv']

import urllib2,urllib,logging,base64,json
color=all_colors[86]
def check_cookies(url,headers={}):
    from Cookie import SimpleCookie
    import cfscrape
    scraper = cfscrape.create_scraper()
    cookies={}
   
    x=scraper.get(url, headers=headers).content
    
    if 'var s={}' in x:
      
      coockie2,token=(get_c(x))
      cookie = SimpleCookie()
      cookie.load(str(coockie2))

      # Even though SimpleCookie is dictionary-like, it internally uses a Morsel object
      # which is incompatible with requests. Manually construct a dictionary instead.
      cookies = {}
      for key, morsel in cookie.items():
            cookies[key] = morsel.value
      cookies['XSRF-TOKEN']=str(token.replace('=','%3D'))
      cookies['max-age']='86400'
    return cookies
def get_c(url):
    from js2py.internals import seval
    regex=",S='(.+?)'"
    s_val=re.compile(regex,re.DOTALL).findall(url)[0]

    regex="var A='(.+?)'"
    a_val=re.compile(regex,re.DOTALL).findall(url)[0]
    s={}
    L=len(s_val)
    U=0
    l=0
    a=0
    r=''
  
    for i in range(0,len(a_val)):
      s[a_val[i]]=i
    for i in range(0,len(s_val)):
     if s_val[i]!='=':
      c=s[s_val[i]]
      U=(U<<6)+c
      
      l+=6
      while (l>=8):
        l=l-8
        
        f=(U>>l)&255
        
         
        a=f;
       
        r+=chr(a);
    
   
    result2=seval.eval_js_vm(r.replace('location.reload();','').replace('document.cookie','document'))
 
    return result2,s_val
    
def read_sparo_html(url,headers={}):
    import cfscrape
    scraper = cfscrape.create_scraper()

    




    cookies=cache.get(check_cookies,3,'https://www.novamovie.net',headers, table='cookies_sp')
   
    x=scraper.get(url, headers=headers,cookies=cookies).content
 
    if 'var s={}' in x :
      
      cookies=cache.get(check_cookies,0,url,headers, table='cookies_sp')
      #cookies=check_cookies(url)
    
      x=scraper.get(url, headers=headers, cookies=cookies)
      
      x.encoding = 'utf-8'
      x=x.content
   
    return x
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    base_link = 'https://www.novamovie.net'
    import cfscrape
    scraper = cfscrape.create_scraper()
    search_id = clean_name(original_title.lower(),1)
    if tv_movie=='movie':
      start_url = '%s/search/%s/' %(base_link,search_id.replace(' ','+'))
    else:
      start_url = '%s/search/%s/' %(base_link,search_id.replace(' ','+')+'+season+'+season)

    headers={'User-Agent':"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"}
    
    html = read_sparo_html(start_url,headers=headers)
  
    match = re.compile('data-movie-id=.+?href="(.+?)".+?class="mli-info"><h2>(.+?)</h2>',re.DOTALL).findall(html)
   
    
    print start_url
    for item_url, name in match:
        if stop_all==1:
              break
        if tv_movie=='movie':
            if not show_original_year in name:
                continue
            name=name.split('(')[0]
           
            if not clean_name(original_title,1).lower().strip() == name.lower().strip():
                continue
        else:
            if not clean_name(original_title,1).lower().strip() in name.lower().strip():
                continue
        headers={'User-Agent':"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",'referer':item_url}
       
        if tv_movie=='tv':
           if item_url.endswith('/'):
              item_url=item_url[:-1]
           item_url=item_url.replace('series','episode')+'-episode-'+episode
 
        OPEN=read_sparo_html(item_url,headers=headers)
        
        
        
     
        Endlinks = re.compile('<iframe class=\'embed-responsive-item\'.+?src="(.+?)"',re.DOTALL).findall(OPEN)

        for link in Endlinks:
           if stop_all==1:
                    break
           
           headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': item_url,
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
                'TE': 'Trailers',
            }
           f_link='http:'+link
           if 'about:blank' in f_link:
            continue
           x=read_sparo_html(f_link,headers)
           regex="<iframe src='(.+?)'"
          
           match2=re.compile(regex).findall(x)
         
           for link in match2:
           
               name2,match_s,res,check=server_data(link,original_title)
               
              
               if check:
                    if 'stream.novamovie.net' in link:
                        
                        regex=('public/dist/index.html\?id=(.+?)&')
                        match=re.compile(regex).findall(link)
                        links='https://stream.novamovie.net/hls/%s/%s.m3u8'%(match[0],match[0])
                        all_links.append((original_title,links,'novamovie',res))
                        
                        global_var=all_links
                    else:
                        all_links.append((name2,link,match_s,res))
                        
                        global_var=all_links
      
           regex='"file":"(.+?)","label":"(.+?)"'
           match2=re.compile(regex).findall(x)
          
           for link,q in match2:
                all_links.append((original_title,link,'Google',q))
                    
                global_var=all_links

           if len (match2)==0:
              regex='"file":"(.+?)"'
              match2=re.compile(regex).findall(x)
             
              for link in match2:
                    all_links.append((original_title,link,'Google',' '))
                        
                    global_var=all_links
    return global_var