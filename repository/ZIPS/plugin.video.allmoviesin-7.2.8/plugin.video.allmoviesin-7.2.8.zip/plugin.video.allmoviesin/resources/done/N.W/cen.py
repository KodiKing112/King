import requests,time
import unjuice,Addon
import json,urllib
import urllib2,logging

global global_var,stop_all#global
global_var=[]
stop_all=0
type=['movie']
from general import clean_name,check_link,server_data,replaceHTMLCodes,all_colors,domain_s,cloudflare_request
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re

color=all_colors[10]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):#CEN
    
    global global_var,stop_all
    sUrl=domain_s+'moviego.net/?s='+(clean_name(original_title,1).replace(' ','+'))
    headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'utf8',
          

            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}
    


    all_links=[]
    user_agent="Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    x,token=cloudflare_request(sUrl)

   
    html= requests.get(sUrl,cookies=token[0],headers=headers).content 

    regex_pre='<article(.+?)</article>'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(html)

    for items in match_pre: 
        if stop_all==1:
              break
        regex='a href=(.+?)>.+?class="Title">(.+?)<.+?class=Year>(.+?)<'
        match=re.compile(regex,re.DOTALL).findall(items)
        
        for item_url, name, rel in match:
            
                                                             
            if not clean_name(original_title,1).lower() == name.lower(): continue
            if not rel == show_original_year: continue
                                                                                    
          
            
          
            count = 0
       
            resp= requests.get(item_url,cookies=token[0],headers=headers)
           
            cookie=resp.cookies
            hd=resp.headers
            html2=resp.content
            if tv_movie=='tv':
              tvshow = re.findall('tv/(.+?)/', html2)[0]
              seaepi_chk = '%sx%s' %(season,episode)
              epi_link =  domain_s+'moviego.net/episode/%s-%s/' % (tvshow, seaepi_chk)
              resp= requests.get(epi_link,cookies=token[0],headers=headers)
              cookie=resp.cookies
              hd=resp.headers
              html2=resp.content
           
            
           
            regex='iframe.+?src="(.+?)"'
            links=re.compile(regex).findall(html2.replace('&quot;','"').replace('&quot;','"').replace('&amp;','&').replace('&#038;','&'))
            for link_pre in links:
             
               if 'image.tmdb.org' not in link_pre:
                if len(link_pre)==0:
                    continue
              
                if stop_all==1:
                    break
                z=requests.get(link_pre,headers=headers)
                z_head=z.headers
                z=z.content
                
                regex='iframe.+?src=(.+?) '
                link=re.compile(regex).findall(z)
              
                if len(link)==0:
                   continue
                else:
                    link=link[0]
                
                if 'youtube' in link:continue;
                if 'sibeol' in link or 'http' not in link:
                    if 'http' not in link:
                        link='https://moviego.net'+link
                        
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
                        'Referer': link_pre,
                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1',
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                        'TE': 'Trailers',
                    }
              
                    if '-player.js' in link:
                        continue
                    r = requests.get(link,cookies=token[0],headers=headers).content
                 
                   
                    data = unjuice.run(r)
                    
                    if data==None:
                      data=r.replace('file','"file"').replace('label','"label"').replace('type','"type"').replace('default','"default"')
                   
                    data = re.findall('sources:([^]]+\])', data, re.DOTALL)
                    if len(data)==0:
                        regex='src="(.+?)"'
                        link_new=re.compile(regex).findall(r)
                        if len(link_new)>0:
                            nam1,srv,res,check=server_data(link_new[0],original_title)
                      
                            if check:
                                all_links.append((nam1.replace("%20"," "),link_new[0],srv,res))
                                global_var=all_links
                    else:
                        data = json.loads(data[0])
                        data = [(i['file'], i['label']) for i in data if data]
                     
                        for end_url, rez in data:
                            
                            
                                if '1080' in rez:
                                    qual = '1080p'
                                elif '720' in rez:
                                    qual ='720p'
                                else:
                                    qual = 'SD'
                                count += 1
                                end_url = '%s|User_Agent=%s&Referer=%s' % (end_url, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36', item_url)
                                all_links.append((original_title,end_url,'Direct',qual))
                                global_var=all_links
           
                    
                else:
                    
                    nam1,srv,res,check=server_data(link,original_title)
                  
                    if check:
                            all_links.append((nam1.replace("%20"," "),link,srv,res))
                            global_var=all_links
    
    return all_links
        
        