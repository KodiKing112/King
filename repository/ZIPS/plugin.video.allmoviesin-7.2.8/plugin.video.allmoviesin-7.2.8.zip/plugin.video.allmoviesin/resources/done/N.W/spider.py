# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,urlparse
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[77]

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    imdb_id=""
    if season!=None and season!="%20":
       url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
    else:
     
       url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
    try:
        imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
    except:
        return 0
    progress='requests'
    api=requests.get('https://api.ipify.org?format=json',headers=base_header).json()['ip']
    key='BwwMswHM4PrTuSju'
    secret='6psfg71bh5sseigwrv16wnv3yfjisb'
    if tv_movie=='tv':
        url='https://videospider.in/getticket.php?key=%s&secret_key=%s&video_id=%s&s=%s&ip=%s'%(key,secret,imdb_id,season,api)
        
    else:
        url='https://videospider.in/getticket.php?key=%s&secret_key=%s&video_id=%s&ip=%s'%(key,secret,imdb_id,api)
        
    
    token=requests.get(url,headers=base_header).content

    if tv_movie=='tv':
        url='https://videospider.stream/getvideo?key=%s&video_id=%s&tv=1&s=%s&e=%s&ticket=%s'%(key,imdb_id,season,episode,token)
    else:
        url='https://videospider.stream/getvideo?key=%s&video_id=%s&ticket=%s&play=1&playref='%(key,imdb_id,token)
    
   
    headers = {
        'authority': 'videospider.stream',
        'pragma': 'no-cache',
        'cache-control': 'no-cache',
        'origin': 'https://videospider.stream',
        'upgrade-insecure-requests': '1',
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
        'sec-fetch-site': 'same-origin',
        'referer': url,
        'accept-encoding': 'utf-8',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
       
    }
    if tv_movie=='tv':
        params = (
            ('key', key),
            ('video_id', imdb_id),
            ('tv','1'),
            ('s',season),
            ('e',episode),
            ('ticket', token),
            ('play', ['1', '1']),
            ('playref', ['', '']),
        )
    else:
        params = (
            ('key', key),
            ('video_id', imdb_id),
            ('ticket', token),
            ('play', ['1', '1']),
            ('playref', ['', '']),
        )

    
    result = requests.post('https://videospider.stream/getvideo', headers=headers, params=params).url
    print result
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Referer': result,
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    response = requests.get('https://oload.party/watch', headers=headers).content
    
    regex=' data-id="(.+?)">(.+?)<'
    m=re.compile(regex).findall(response)
    for id,host in m:
        
        if 'verystream' in host:
            link='https://verystream.com/e/'+id
        elif 'openload' in host:
            link='https://oload.site/embed/'+id
        elif 'gounlimited' in host:
            link='https://gounlimited.to/embed-%s.html'%id
        elif 'streamango' in host:
           link='https://streamango.com/embed/'+id
        elif 'vidcloud' in host:
            link='https://vidcloud.icu/load.php?id='+id
        elif 'xstreamcdn' in host:
            link='https://xstreamcdn.com/v/'+id
        elif 'vidlox' in host:
            link='https://vidlox.me/embed-%s.html'%id
        elif 'flix555' in host:
            link='https://flix555.com/embed-%s.html'%id
        elif 'rapidvideo' in host:
            link='https://www.rapidvideo.com/e/'+id
        elif 'clipwatching' in host:
            link='https://clipwatching.com/embed-%s.html'%id
        
        print link
        name1,match_s,res,check=server_data(link,original_title)
      
        if check:
            all_links.append((name1.replace("%20"," "),link,match_s,res))                
                    
            global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var